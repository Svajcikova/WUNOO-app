# WUNOO v1.383 Candidate — v1.18 refund idempotency lock ordering

## Change
- The legacy `/api/v118/orders/{order_id}/command` route now acquires the canonical PostgreSQL order row lock before reading the idempotency command log when `action=refund`.
- This serializes same-key refund replays before cache lookup, avoiding a duplicate command-log insert race after a concurrent refund waits on the order lock.
- SQLite behavior is unchanged: `BEGIN IMMEDIATE` already serializes the command before the idempotency read.

## Verification
- `TEST_V383.py` — source-order invariant plus runtime command-log replay and changed-payload conflict test.
- `TEST_V382.py` — PASS.
- `TEST_V381.py` — PASS.
- `TEST_V380.py` — PASS.
- `TEST_V379.py` — PASS.
- `TEST_V378.py` — PASS.
- `TEST_V377.py` — PASS.
- `python -m compileall -q app` — PASS.
- PostgreSQL integration concurrency test remains outstanding; this environment does not have a PostgreSQL driver/server configured.

## Status
Candidate only; not production-approved and not pushed to GitHub.
