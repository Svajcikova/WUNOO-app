import os, tempfile
DB=os.path.join(tempfile.gettempdir(),'wunoo_v358_pickup_state.db')
try: os.remove(DB)
except FileNotFoundError: pass
os.environ['WUNOO_DB_PATH']=DB
import app.main as m
m.init_db()
with m.core_db_connect() as c:
    for name in 'migrate_v046 migrate_v052 migrate_v053 migrate_v061 migrate_v119 migrate_v120 migrate_v121 migrate_v122 migrate_v310 migrate_v311 migrate_v312 migrate_v313 migrate_v314 migrate_v315 migrate_v316 migrate_v318 migrate_v319 migrate_v321 migrate_v322 migrate_v323 migrate_v325 migrate_v326 migrate_v328 migrate_v329 migrate_v330 migrate_v331 migrate_v332 migrate_v333 migrate_v334 migrate_v335 migrate_v336 migrate_v337 migrate_v338 migrate_v339 migrate_v340 migrate_v341 migrate_v342 migrate_v343 migrate_v344 migrate_v345 migrate_v346 migrate_v347 migrate_v348 migrate_v349 migrate_v350 migrate_v351 migrate_v352 migrate_v353 migrate_v354 migrate_v355 migrate_v356 migrate_v357'.split():
        fn=getattr(m,name,None)
        if fn: fn(c)
    ts=m.now()
    c.execute("INSERT INTO merchants(id,name,created_at) VALUES(?,?,?)",('v358_m','V358',ts))
    c.execute("INSERT INTO customers(id,name,email,created_at) VALUES(?,?,?,?)",('v358_c','V358','v358@test',ts))
    c.execute("INSERT INTO couriers(id,name,status,created_at) VALUES(?,?,?,?)",('v358_r','V358','online',ts))
    c.execute("INSERT INTO orders(id,customer_id,merchant_id,status,subtotal_czk,service_fee_czk,delivery_fee_czk,total_czk,address,courier_id,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",('v358_o','v358_c','v358_m','courier_assigned',100,0,0,100,'A','v358_r',ts,ts))
    c.commit()
with m.core_db_connect() as c:
    o=c.execute("SELECT * FROM orders WHERE id='v358_o'").fetchone()
    actor={'id':'v358_actor','role':'courier','courier_id':'v358_r'}
    m.transition(c,'v358_o','courier_assigned','picked_up',actor,'pickup_completed',{'courier_id':'v358_r'})
    c.commit()
with m.core_db_connect() as c:
    o=c.execute("SELECT status,courier_id FROM orders WHERE id='v358_o'").fetchone()
    assert o['status']=='picked_up',dict(o)
    ev=c.execute("SELECT COUNT(*) n FROM events WHERE order_id='v358_o' AND type='pickup_completed'").fetchone()['n']
    assert ev==1,ev
print('V358_CANONICAL_PICKUP_TRANSITION PASS')
