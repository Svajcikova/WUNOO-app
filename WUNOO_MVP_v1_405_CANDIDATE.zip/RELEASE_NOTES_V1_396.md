# WUNOO v1.396 Candidate

## Summary

Hardens refund-ledger idempotency. Previously, `_v234_record_refund_ledger` returned early if *any* ledger row existed for the refund provider reference. That could silently accept an incomplete or inconsistent ledger pair, rather than confirming the complete debit/credit pair.

## Change

- Existing refund ledger entries are now checked as a complete pair before an idempotent return.
- The pair must belong to the same order and amount, with `customer_refunds/debit` and `payment_clearing/credit` entries.
- Partial, malformed, wrong-amount, or cross-order existing records fail closed with HTTP 409 `REFUND_LEDGER_INCONSISTENT`.
- Fresh refund ledger writes and exact replays retain their previous behavior.

## Verification performed on this candidate

- `python -m compileall -q app` — PASS.
- `TEST_V396.py` — PASS: exact replay is idempotent; a partial ledger pair returns HTTP 409.
- `TEST_V395.py` — PASS.
- `TEST_V394.py` — PASS.
- `TEST_V393.py` — PASS.
- `TEST_V392.py` — PASS.
- `TEST_V391.py` — PASS.
- `TEST_V390.py` — PASS.
- `TEST_V389.py` — PASS.
- `TEST_V362.py` — PASS.
- ZIP archive integrity verified after packaging.

## Limitations

This is a candidate build, not production approval. The regression tests above use the local SQLite test setup; PostgreSQL concurrency/integration, an actual payment provider, and deployment were not verified. No GitHub push or deployment was performed.
