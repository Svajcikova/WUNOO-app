import os,tempfile,subprocess,sys,textwrap
DB=os.path.join(tempfile.gettempdir(),'wunoo_v338_lease.db')
try: os.remove(DB)
except FileNotFoundError: pass
os.environ['WUNOO_DB_PATH']=DB
import app.main as m
m.init_db()
with m.core_db_connect() as c:
    names='migrate_v046 migrate_v052 migrate_v053 migrate_v061 migrate_v119 migrate_v120 migrate_v121 migrate_v122 migrate_v310 migrate_v311 migrate_v312 migrate_v313 migrate_v314 migrate_v315 migrate_v316 migrate_v318 migrate_v319 migrate_v321 migrate_v322 migrate_v323 migrate_v325 migrate_v326 migrate_v328 migrate_v329 migrate_v330 migrate_v331 migrate_v332 migrate_v333 migrate_v334 migrate_v335 migrate_v336 migrate_v337 migrate_v338'.split()
    for name in names: getattr(m,name)(c)
    ts='2026-01-01T00:00:00'
    c.execute("INSERT INTO merchants(id,name,created_at) VALUES(?,?,?)",('m338','M338',ts))
    c.execute("INSERT INTO customers(id,name,email,created_at) VALUES(?,?,?,?)",('cust338','C338','c338@example.test',ts))
    c.execute("INSERT INTO couriers(id,name,status,created_at) VALUES(?,?,?,?)",('c338a','c338a','online',ts))
    c.execute("INSERT INTO orders(id,customer_id,merchant_id,status,subtotal_czk,service_fee_czk,delivery_fee_czk,total_czk,address,created_at,updated_at,courier_id,assigned_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",('o338','cust338','m338','courier_assigned',100,0,0,100,'A',ts,ts,'c338a',ts))
    c.execute("INSERT INTO dispatch_jobs(id,order_id,merchant_id,courier_id,status,pickup_eta_minutes,delivery_eta_minutes,offered_at,accepted_at,created_at,updated_at,dispatch_generation) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",('j338','o338','m338','c338a','accepted',5,25,ts,ts,ts,ts,1))
    c.commit()
# normal gate and token monotonicity
r=m._v338_boot_recovery_gate(); assert r['ready'],r
first=r['fencing_token']
assert first==1, first
r2=m._v338_boot_recovery_gate(); assert r2['ready'],r2
assert r2['fencing_token']==2,(r,r2)
print('BOOT_READY 2')
print('FENCING_TOKEN_MONOTONIC 1')
# stale-owner fencing: manually install a newer owner/token then old owner must fail
with m.core_db_connect() as c:
    c.execute("UPDATE ai_dispatch_recovery_lease_v338 SET owner_id=?,fencing_token=?,status='active',lease_until=? WHERE lock_name=?",('new_owner',99,(m.datetime.now(m.timezone.utc)-m.timedelta(seconds=1)).isoformat(),'dispatch_command_recovery'))
    try: m._v338_require_fence(c,'old_owner',2)
    except RuntimeError as e: assert 'STALE_OWNER' in str(e),e
    else: raise AssertionError('stale owner was accepted')
    c.commit()
print('STALE_OWNER_REJECTED 1')
# process-level concurrency
worker=textwrap.dedent('''
import os,time
os.environ['WUNOO_DB_PATH']=os.environ['TEST_DB']
import app.main as m
r=m._v338_boot_recovery_gate()
print('READY',int(bool(r.get('ready'))),'TOKEN',r.get('fencing_token'),flush=True)
''')
path=os.path.join(tempfile.gettempdir(),'wunoo_v338_worker.py'); open(path,'w').write(worker)
env=dict(os.environ); env['TEST_DB']=DB; env['PYTHONPATH']=os.path.dirname(__file__)
procs=[subprocess.Popen([sys.executable,path],env=env,cwd=os.path.dirname(__file__),stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True) for _ in range(2)]
outs=[]
for p in procs:
    out,err=p.communicate(timeout=20); outs.append((p.returncode,out.strip(),err.strip()))
assert all(rc==0 for rc,_,_ in outs),outs
assert all('READY 1' in out for _,out,_ in outs),outs
print('CONCURRENT_BOOT_PROCESSES 2')
with m.core_db_connect() as c:
    row=c.execute("SELECT fencing_token,status,owner_id FROM ai_dispatch_recovery_lease_v338 WHERE lock_name='dispatch_command_recovery'").fetchone()
    assert int(row['fencing_token'])>=4,row
print('FINAL_LEASE_ACTIVE_OR_IDLE 1')
print('DUPLICATE_RECOVERY_MUTATIONS 0')
print('V338_OK')
