from pathlib import Path
source=(Path(__file__).parent/"app"/"main.py").read_text(encoding="utf-8")
def route(start_marker,end_marker):
    start=source.index(start_marker)
    end=source.index(end_marker,start)
    return source[start:end]
checks=[
    (route('@app.post("/api/v049/orders/{order_id}/payment-intent")','@app.post("/api/v049/orders/{order_id}/capture")'),"v049_payment_intent_insert","/api/v049"),
    (route('@app.post("/api/v059/payment/create")','@app.post("/api/v059/payment/webhook")'),"v059_payment_intent_insert","/api/v059"),
]
for body,savepoint,label in checks:
    assert f"SAVEPOINT {savepoint}" in body, f"{label}: missing savepoint"
    assert f"ROLLBACK TO SAVEPOINT {savepoint}" in body, f"{label}: missing rollback recovery"
    assert "SELECT * FROM payment_intents WHERE order_id=?" in body, f"{label}: no winner lookup"
    assert "if not existing:" in body and "raise" in body, f"{label}: must fail closed if no winner"
    assert "Existující payment intent neodpovídá částce objednávky" in body, f"{label}: amount mismatch not guarded"
print("V376_PAYMENT_INTENT_CONCURRENCY_RECOVERY_PASS routes=2")
