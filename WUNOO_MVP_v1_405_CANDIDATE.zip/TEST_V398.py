"""v1.398 regression: refund ledger metadata amount must be a JSON number."""
import os, sys, tempfile, uuid, json
from pathlib import Path
from fastapi import HTTPException
ROOT = Path(__file__).resolve().parent
os.environ['WUNOO_DB_PATH'] = os.path.join(tempfile.gettempdir(), 'wunoo_v398_' + uuid.uuid4().hex + '.db')
sys.path.insert(0, str(ROOT))
from app import main
main.init_db()

def conflict(fn):
    try:
        fn()
    except HTTPException as exc:
        assert exc.status_code == 409 and exc.detail['code'] == 'REFUND_LEDGER_INCONSISTENT', (exc.status_code, exc.detail)
    else:
        raise AssertionError('malformed metadata amount was accepted')

def run_case(refund_id, provider_ref, bad_value):
    order_id, amount = 'order-' + refund_id, 1.00
    with main.conn() as c:
        main._v234_record_refund_ledger(c, order_id, amount, provider_ref, refund_id)
        c.commit()
        row = c.execute("SELECT id,metadata_json FROM finance_ledger_entries WHERE entry_type='refund_v234' AND reference=? ORDER BY account LIMIT 1", (provider_ref,)).fetchone()
        meta = json.loads(row['metadata_json'])
        meta['amount_czk'] = bad_value
        c.execute('UPDATE finance_ledger_entries SET metadata_json=? WHERE id=?', (json.dumps(meta), row['id']))
        c.commit()
        conflict(lambda: main._v234_record_refund_ledger(c, order_id, amount, provider_ref, refund_id))

with main.conn() as c:
    main._v234_record_refund_ledger(c, 'order-valid', 1.00, 'provider-valid', 'refund-valid')
    c.commit()
    main._v234_record_refund_ledger(c, 'order-valid', 1.00, 'provider-valid', 'refund-valid')
    assert c.execute("SELECT COUNT(*) n FROM finance_ledger_entries WHERE entry_type='refund_v234' AND reference='provider-valid'").fetchone()['n'] == 2
run_case('refund-bool', 'provider-bool', True)
run_case('refund-string', 'provider-string', '1.0')
print('V398_REFUND_METADATA_NUMERIC_TYPE_GUARD_PASS exact_replay=PASS bool_rejected=409 numeric_string_rejected=409')
