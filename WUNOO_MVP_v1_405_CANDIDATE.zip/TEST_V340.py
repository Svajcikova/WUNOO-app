import os,tempfile,subprocess,sys,textwrap,time,signal
DB=os.path.join(tempfile.gettempdir(),'wunoo_v340_matrix.db')
try: os.remove(DB)
except FileNotFoundError: pass
os.environ['WUNOO_DB_PATH']=DB
import app.main as m
m.init_db()
# Ensure current migration exists even if init_db version selection changes.
with m.core_db_connect() as c:
    names='migrate_v046 migrate_v052 migrate_v053 migrate_v061 migrate_v119 migrate_v120 migrate_v121 migrate_v122 migrate_v310 migrate_v311 migrate_v312 migrate_v313 migrate_v314 migrate_v315 migrate_v316 migrate_v318 migrate_v319 migrate_v321 migrate_v322 migrate_v323 migrate_v325 migrate_v326 migrate_v328 migrate_v329 migrate_v330 migrate_v331 migrate_v332 migrate_v333 migrate_v334 migrate_v335 migrate_v336 migrate_v337 migrate_v338 migrate_v339 migrate_v340'.split(); [getattr(m,name)(c) for name in names]
    c.commit()
# Process that acquires a durable lease and is then SIGKILLed.
worker=textwrap.dedent('''
import os,time
os.environ['WUNOO_DB_PATH']=os.environ['TEST_DB']
import app.main as m
m.init_db()
with m.core_db_connect() as c:
    m.migrate_v310(c); m.migrate_v311(c); m.migrate_v312(c); m.migrate_v313(c); m.migrate_v314(c); m.migrate_v315(c); m.migrate_v316(c); m.migrate_v318(c); m.migrate_v319(c); m.migrate_v321(c); m.migrate_v322(c); m.migrate_v323(c); m.migrate_v325(c); m.migrate_v326(c); m.migrate_v328(c); m.migrate_v329(c); m.migrate_v330(c); m.migrate_v331(c); m.migrate_v332(c); m.migrate_v333(c); m.migrate_v334(c); m.migrate_v335(c); m.migrate_v336(c); m.migrate_v337(c); m.migrate_v338(c); m.migrate_v339(c); m.migrate_v340(c)
with m.core_db_connect() as c:
    m._v337_recovery_lock(c)
    owner='sigkill340_'+m.uuid.uuid4().hex[:12]
    token=m._v338_acquire_lease(c,owner)
    m._v338_require_fence(c,owner,token)
    c.commit()
    print('LEASE_ACQUIRED',owner,token,flush=True)
    time.sleep(60)
''')
path=os.path.join(tempfile.gettempdir(),'wunoo_v340_sigkill_worker.py'); open(path,'w').write(worker)
env=dict(os.environ); env['TEST_DB']=DB; env['PYTHONPATH']=os.path.join(os.path.dirname(__file__))
p=subprocess.Popen([sys.executable,path],env=env,cwd=os.path.dirname(__file__),stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
line=p.stdout.readline().strip(); assert line.startswith('LEASE_ACQUIRED'),line
parts=line.split(); old_owner=parts[1]; old_token=int(parts[2])
os.kill(p.pid,signal.SIGKILL); p.wait(timeout=10)
print('SIGKILL_OWNER 1')
# Make the durable lease expired, then run the real recovery matrix takeover logic.
with m.core_db_connect() as c:
    c.execute("UPDATE ai_dispatch_recovery_lease_v338 SET lease_until=? WHERE lock_name=?",((m.datetime.now(m.timezone.utc)-m.timedelta(seconds=1)).isoformat(),'dispatch_command_recovery'))
    c.commit()
print('LEASE_EXPIRED_AFTER_CRASH 1')
r=m._v340_full_system_crash_matrix(record=True)
assert r['passed'] and r['new_fencing_token']>r['old_fencing_token'],r
print('TAKEOVER_AFTER_SIGKILL 1')
print('STALE_OWNER_FENCED 1')
print('JOURNAL_INTEGRITY 1')
print('DUPLICATE_RECOVERY_MUTATIONS 0')
print('UNRESOLVED_PROVABLE_RESIDUES 0')
print('V340_OK')
