from pathlib import Path
source=(Path(__file__).parent/"app"/"main.py").read_text(encoding="utf-8")
def route(start_marker,end_marker):
    start=source.index(start_marker)
    end=source.index(end_marker,start)
    return source[start:end]
checks=[
    (route('@app.post("/api/v049/orders/{order_id}/payment-intent")','@app.post("/api/v049/orders/{order_id}/capture")'),"v049"),
    (route('@app.post("/api/v059/payment/create")','@app.post("/api/v059/payment/webhook")'),"v059"),
]
for body,label in checks:
    assert 'if existing:' in body, f"{label}: missing existing-intent branch"
    branch=body.split("if existing:",1)[1].split("else:",1)[0]
    assert 'existing["amount_czk"]' in branch and 'o["total_czk"]' in branch, f"{label}: amount consistency not checked on replay"
    assert 'existing["currency"]' in branch and 'HTTPException(409' in branch, f"{label}: currency consistency not checked on replay"
print("V377_EXISTING_PAYMENT_INTENT_AMOUNT_CURRENCY_REPLAY_GUARD_PASS routes=2")
