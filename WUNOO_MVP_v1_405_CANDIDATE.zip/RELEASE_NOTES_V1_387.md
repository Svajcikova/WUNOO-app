# WUNOO v1.387 Candidate — v1.141 webhook consistency hardening

## Changes
- `/api/v141/payment/webhook` now binds each provider event ID to the exact JSON payload, event type, and payment-intent ID. Reuse of an event ID with different content returns HTTP 409 instead of being silently accepted as a duplicate.
- New v1.141 webhook rows now persist `payment_intent_id`, enabling explicit event-to-intent verification and matching the v1.140 path.
- Terminal payment states are now immutable across contradictory events: a late failure/cancellation after success is ignored; failed/cancelled versus success or the other terminal state is recorded as a conflict and rejected with HTTP 409.
- The payment-intent status is changed to `succeeded` only after confirming the order is still `payment_pending`, preventing an invalid late success from mutating the intent before the order-state guard.
- Added `TEST_V387.py` for exact replay, changed payload, late failure after success, and failed-to-cancelled contradiction.

## Verification
- `python -m compileall -q app` — PASS.
- `TEST_V387.py` — PASS: exact replay returns 200 duplicate, changed payload returns 409, late failure after success is ignored, and failed-to-cancelled transition returns 409 without changing the terminal intent.
- Selected regression tests `TEST_V362.py`, `TEST_V365.py` through `TEST_V386.py` (including `TEST_V377_runtime.py`) — PASS when run individually. The batch process exceeded its overall time budget during V385; V385, V386, and V387 were then rerun individually and passed.
- ZIP integrity — verified after archive creation.

## Limitations / status
- The new v1.141 route test mocks the finality helper to isolate webhook state handling; payment-finality accounting is covered separately by the existing V362 lifecycle test. This does not replace an end-to-end provider/database integration test.
- No live PostgreSQL integration test was run. SQLite tests and source-level PostgreSQL row-lock logic do not prove production PostgreSQL concurrency behavior.
- Candidate only; not production-approved and not pushed to GitHub.
