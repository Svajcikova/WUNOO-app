from app.main import _v349_conformance
r=_v349_conformance()
assert r['passed'] is True
assert r['scenarios']==3
assert r['failures']==0
assert r['phase_mismatches']==0
assert r['rollback_verified'] is True
assert r['stale_owner_fenced'] is True
print('V349_OK')
print('SCENARIOS',r['scenarios'])
print('FAILURES',r['failures'])
print('PHASE_MISMATCHES',r['phase_mismatches'])
print('ROLLBACK_VERIFIED',r['rollback_verified'])
print('STALE_OWNER_FENCED',r['stale_owner_fenced'])
