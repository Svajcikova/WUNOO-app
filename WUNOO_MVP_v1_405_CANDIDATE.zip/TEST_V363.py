from app.main import _v363_bootstrap_test
r=_v363_bootstrap_test()
print('V363_BOOTSTRAP_PASS', r)
