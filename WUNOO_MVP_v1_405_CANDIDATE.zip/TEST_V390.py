"""v1.390 regression: reject boolean/non-finite webhook amounts in legacy v059 and v140."""
import os, sys, json, hmac, hashlib, tempfile, uuid, math
from pathlib import Path
from fastapi.testclient import TestClient
ROOT=Path(__file__).resolve().parent
os.environ['WUNOO_PAYMENT_WEBHOOK_SECRET']='test-secret-v390'
os.environ['WUNOO_DB_PATH']=os.path.join(tempfile.gettempdir(),'wunoo_v390_'+uuid.uuid4().hex+'.db')
sys.path.insert(0,str(ROOT))
from app import main
main.transition=lambda *args,**kwargs: None
main.emit=lambda *args,**kwargs: None
suffix=uuid.uuid4().hex[:10]; stamp=main.now()
def send(client,path,body):
    raw=json.dumps(body,separators=(',',':'),allow_nan=True).encode()
    sig='sha256='+hmac.new(b'test-secret-v390',raw,hashlib.sha256).hexdigest()
    return client.post(path,content=raw,headers={'X-WUNOO-Signature':sig,'Content-Type':'application/json'})
with TestClient(main.app) as client:
    with main.conn() as c:
        main.migrate_v049(c); main.migrate_v059(c); main.migrate_v140(c)
        cid='c_v390_'+suffix; mid='m_v390_'+suffix
        c.execute("INSERT INTO customers(id,name,email,created_at) VALUES(?,?,?,?)",(cid,'V390 Customer',cid+'@x.test',stamp))
        c.execute("INSERT INTO merchants(id,name,created_at) VALUES(?,?,?)",(mid,'V390 Merchant',stamp))
        for api, amount in [('v059',1),('v140',1)]:
            oid=f'o_v390_{api}_{suffix}'; pid=f'pi_v390_{api}_{suffix}'
            c.execute("INSERT INTO orders(id,customer_id,merchant_id,status,subtotal_czk,service_fee_czk,delivery_fee_czk,total_czk,address,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(oid,cid,mid,'payment_pending',1,0,0,1,'V390',stamp,stamp))
            c.execute("INSERT INTO payment_intents(id,order_id,amount_czk,currency,status,provider,provider_intent_id,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",(pid,oid,amount,'CZK','requires_payment_method','test','prov_'+pid,stamp,stamp))
        c.commit()
    cases=['not-a-number', True, float('inf'), float('nan')]
    for api,path in [('v059','/api/v059/payment/webhook'),('v140','/api/v140/payment/webhook')]:
        pid=f'pi_v390_{api}_{suffix}'
        for idx,bad in enumerate(cases):
            event=f'evt_v390_{api}_{idx}_{suffix}'
            r=send(client,path,{'id':event,'type':'payment_succeeded','payment_intent_id':pid,'amount_czk':bad,'currency':'CZK'})
            assert r.status_code==400 and r.json().get('detail',{}).get('code')=='PAYMENT_AMOUNT_INVALID',(api,repr(bad),r.status_code,r.text)
        with main.conn() as c:
            state=c.execute('SELECT status FROM payment_intents WHERE id=?',(pid,)).fetchone()['status']
            event_count=c.execute('SELECT COUNT(*) n FROM payment_webhook_events WHERE provider_event_id LIKE ?',(f'evt_v390_{api}_%_{suffix}',)).fetchone()['n']
        assert state=='requires_payment_method' and event_count==0,(api,state,event_count)
    print('V390_LEGACY_WEBHOOK_FINITE_AMOUNT_GUARD_PASS apis=v059,v140 cases=4_each bool_match_case_rejected=true no_mutation=true')
