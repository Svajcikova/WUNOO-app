import os, sys, uuid
sys.path.insert(0, os.path.dirname(__file__))
from app import main
from fastapi import HTTPException

main.init_db()
with main.conn() as c:
    main.migrate_v049(c)
    main.migrate_v052(c)
    main.migrate_v059(c)
uid='u_v377_'+uuid.uuid4().hex[:8]
cid='c_v377_'+uuid.uuid4().hex[:8]
mid='m_v377_'+uuid.uuid4().hex[:8]
now=main.now()
orders=[]
with main.conn() as c:
    c.execute("INSERT INTO users(id,email,name,role,active,created_at,password_hash) VALUES(?,?,?,?,?,?,?)",(uid,uid+'@x.test','V377','customer',1,now,'x'))
    c.execute("INSERT INTO customers(id,name,email,created_at) VALUES(?,?,?,?)",(cid,'V377 Customer',uid+'@x.test',now))
    c.execute("INSERT INTO merchants(id,name,created_at) VALUES(?,?,?)",(mid,'V377 Merchant',now))
    for route, mismatch, amount, currency in [
        ('v049','amount',119,'CZK'),('v049','currency',120,'USD'),
        ('v059','amount',119,'CZK'),('v059','currency',120,'USD')]:
        oid='o_v377_'+uuid.uuid4().hex[:8]
        pid='pi_v377_'+uuid.uuid4().hex[:8]
        c.execute("INSERT INTO orders(id,customer_id,merchant_id,status,subtotal_czk,service_fee_czk,delivery_fee_czk,total_czk,address,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(oid,cid,mid,'payment_pending',100,10,10,120,'V377',now,now))
        c.execute("INSERT INTO payment_intents(id,order_id,amount_czk,currency,status,provider,provider_intent_id,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",(pid,oid,amount,currency,'requires_payment_method','test','prov_'+pid,now,now))
        orders.append((route,mismatch,oid,pid))
    c.commit()
original_current_user=main.current_user
main.current_user=lambda authorization: {'id':uid,'role':'customer','customer_id':cid}
try:
    for route,mismatch,oid,pid in orders:
        fn=(lambda oid=oid: main.v049_payment_intent(oid,None)) if route=='v049' else (lambda oid=oid: main.v059_payment_create({'order_id':oid},None,'v377-'+uuid.uuid4().hex))
        try:
            fn()
            raise AssertionError(f'{route}_{mismatch}: invalid existing intent was accepted')
        except HTTPException as e:
            assert e.status_code==409, (route,mismatch,e.status_code,e.detail)
finally:
    main.current_user=original_current_user
    with main.conn() as c:
        for _,_,oid,pid in orders:
            c.execute('DELETE FROM payment_intents WHERE id=?',(pid,))
            c.execute('DELETE FROM orders WHERE id=?',(oid,))
        c.execute('DELETE FROM customers WHERE id=?',(cid,))
        c.execute('DELETE FROM merchants WHERE id=?',(mid,))
        c.execute('DELETE FROM users WHERE id=?',(uid,))
        c.commit()
print('V377_RUNTIME_INVALID_EXISTING_INTENT_REJECTED routes=2 cases=4 amount_and_currency=PASS')
