import os, sys
os.environ.setdefault('WUNOO_DB_PATH', '/tmp/wunoo_v347_test.db')
try: os.remove(os.environ['WUNOO_DB_PATH'])
except FileNotFoundError: pass
sys.path.insert(0, os.path.dirname(__file__))
from app.main import _v347_property_chaos
r=_v347_property_chaos()
assert r['passed'] is True
assert r['cases']==5000
assert r['failures']==0
assert r['invalid_transition_accepts']==0
assert r['stale_mutations']==0
assert r['double_commits']==0
print('V347_OK')
print('CASES',r['cases'])
print('FAILURES',r['failures'])
print('INVALID_TRANSITION_ACCEPTS',r['invalid_transition_accepts'])
print('STALE_MUTATIONS',r['stale_mutations'])
print('DOUBLE_COMMITS',r['double_commits'])
