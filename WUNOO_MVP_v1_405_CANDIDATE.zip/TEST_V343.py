import os,tempfile
DB=os.path.join(tempfile.gettempdir(),'wunoo_v343_test.db')
try: os.remove(DB)
except FileNotFoundError: pass
os.environ['WUNOO_DB_PATH']=DB
import app.main as m
m.init_db()
with m.core_db_connect() as c:
    names='migrate_v046 migrate_v052 migrate_v053 migrate_v061 migrate_v119 migrate_v120 migrate_v121 migrate_v122 migrate_v310 migrate_v311 migrate_v312 migrate_v313 migrate_v314 migrate_v315 migrate_v316 migrate_v318 migrate_v319 migrate_v321 migrate_v322 migrate_v323 migrate_v325 migrate_v326 migrate_v328 migrate_v329 migrate_v330 migrate_v331 migrate_v332 migrate_v333 migrate_v334 migrate_v335 migrate_v336 migrate_v337 migrate_v338 migrate_v339 migrate_v340 migrate_v341 migrate_v342 migrate_v343'.split()
    for n in names:
        getattr(m,n)(c)
    c.commit()
r=m._v343_crash_matrix()
assert r['passed'],r
assert len(r['results'])==7,r
assert all(x['rollback_verified'] for x in r['results']),r
assert not r['final_snapshot']['lease_active'],r
print('CRASH_POINTS 7')
print('ROLLBACK_VERIFIED 7')
print('ACTIVE_LEASE_AFTER_CRASH 0')
print('POST_CRASH_DB_USABLE 1')
print('V343_OK')
