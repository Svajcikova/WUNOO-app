from app.main import _v353_chaos
r=_v353_chaos(cycles=4)
assert r['passed'] is True
assert r['cycles']==4
assert r['failures']==0
assert r['takeovers_verified']==4
assert r['concurrent_workers']==2
assert r['concurrent_completed']==8
assert r['boot_recovered']==4
assert r['lease_clean']==4
assert r['journal_clean']==4
assert r['fencing_monotonic'] is True
print('V353_OK')
print('CYCLES',r['cycles'])
print('FAILURES',r['failures'])
print('TAKEOVERS_VERIFIED',r['takeovers_verified'])
print('CONCURRENT_COMPLETED',r['concurrent_completed'])
print('BOOT_RECOVERED',r['boot_recovered'])
print('LEASE_CLEAN',r['lease_clean'])
print('JOURNAL_CLEAN',r['journal_clean'])
print('FENCING_MONOTONIC',r['fencing_monotonic'])
