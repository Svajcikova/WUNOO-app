import os,tempfile
DB=os.path.join(tempfile.gettempdir(),'wunoo_v345_test.db')
try: os.remove(DB)
except FileNotFoundError: pass
os.environ['WUNOO_DB_PATH']=DB
import app.main as m
m.init_db()
with m.closing(m.conn()) as c:
    m._run_all_migrations(c)
    assert m._v341_table_exists(c,'ai_dispatch_recovery_adversarial_chaos_v345')
r=m._v345_full_adversarial_chaos()
assert r['passed'],r
assert len(r['results'])==6,r
assert r['stale_mutations']==0,r
assert r['duplicate_recovery_mutations']==0,r
assert r['partial_evidence']==0,r
assert r['unresolved_provable_residues']==0,r
assert sum(x['sigkill_workers'] for x in r['results'])==4,r
print('ADVERSARIAL_ITERATIONS 6')
print('SIGKILL_SCENARIOS 4')
print('STALE_MUTATIONS 0')
print('DUPLICATE_RECOVERY_MUTATIONS 0')
print('PARTIAL_EVIDENCE 0')
print('UNRESOLVED_PROVABLE_RESIDUES 0')
print('V345_OK')
