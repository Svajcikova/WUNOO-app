import os, sys, json, hmac, hashlib
sys.path.insert(0, os.path.dirname(__file__))
from app import main
from fastapi.testclient import TestClient

os.environ['WUNOO_PAYMENT_WEBHOOK_SECRET']='test-secret-v372'
client=TestClient(main.app)
main.init_db()
main.transition=lambda *args, **kwargs: None
main._v053_log=lambda *args, **kwargs: None
main.migrate_v049(main.conn())
main.migrate_v059(main.conn())

# Use existing app helpers to create an isolated customer/order/payment intent.
with main.conn() as c:
    uid='u_v372_'+__import__('uuid').uuid4().hex[:8]
    cid='c_v372_'+__import__('uuid').uuid4().hex[:8]
    mid='m_v372_'+__import__('uuid').uuid4().hex[:8]
    oid='o_v372_'+__import__('uuid').uuid4().hex[:8]
    pid='pi_v372_'+__import__('uuid').uuid4().hex[:8]
    now=main.now()
    # Ensure supporting rows exist with minimal schema-compatible fields.
    c.execute("INSERT INTO users(id,email,name,role,active,created_at,password_hash) VALUES(?,?,?,?,?,?,?)",(uid,uid+'@x.test','V372','customer',1,now,'x'))
    c.execute("INSERT INTO customers(id,name,email,created_at) VALUES(?,?,?,?)",(cid,'V372 Customer',uid+'@x.test',now))
    c.execute("INSERT INTO merchants(id,name,created_at) VALUES(?,?,?)",(mid,'V372 Merchant',now))
    c.execute("INSERT INTO orders(id,customer_id,merchant_id,status,subtotal_czk,service_fee_czk,delivery_fee_czk,total_czk,address,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(oid,cid,mid,'payment_pending',100,10,10,120,'V372',now,now))
    c.execute("INSERT INTO payment_intents(id,order_id,amount_czk,currency,status,provider,provider_intent_id,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",(pid,oid,120,'CZK','requires_payment_method','test','prov_'+pid,now,now))
    c.commit()

def signed(body):
    raw=json.dumps(body,separators=(',',':')).encode()
    sig='sha256='+hmac.new(b'test-secret-v372',raw,hashlib.sha256).hexdigest()
    return raw,sig

raw,sig=signed({'id':'evt_v372_bad_amount_'+__import__('uuid').uuid4().hex,'type':'payment_succeeded','payment_intent_id':pid,'amount_czk':1,'currency':'CZK'})
r=client.post('/api/v059/payment/webhook',content=raw,headers={'X-WUNOO-Signature':sig,'Content-Type':'application/json'})
assert r.status_code==409, r.text
with main.conn() as c:
    row=c.execute('SELECT status FROM payment_intents WHERE id=?',(pid,)).fetchone()
    assert row['status']=='requires_payment_method', row

raw,sig=signed({'id':'evt_v372_ok_'+__import__('uuid').uuid4().hex,'type':'payment_succeeded','payment_intent_id':pid,'amount_czk':120,'currency':'CZK'})
r=client.post('/api/v059/payment/webhook',content=raw,headers={'X-WUNOO-Signature':sig,'Content-Type':'application/json'})
assert r.status_code==200, r.text
with main.conn() as c:
    row=c.execute('SELECT status FROM payment_intents WHERE id=?',(pid,)).fetchone()
    assert row['status']=='succeeded', row
print('V372_LEGACY_WEBHOOK_AMOUNT_CURRENCY_GUARD_PASS')
