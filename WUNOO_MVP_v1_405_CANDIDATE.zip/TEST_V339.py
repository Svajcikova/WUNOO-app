import os,tempfile,subprocess,sys,textwrap
DB=os.path.join(tempfile.gettempdir(),'wunoo_v339_chaos.db')
try: os.remove(DB)
except FileNotFoundError: pass
os.environ['WUNOO_DB_PATH']=DB
import app.main as m
m.init_db()
with m.core_db_connect() as c:
    names='migrate_v046 migrate_v052 migrate_v053 migrate_v061 migrate_v119 migrate_v120 migrate_v121 migrate_v122 migrate_v310 migrate_v311 migrate_v312 migrate_v313 migrate_v314 migrate_v315 migrate_v316 migrate_v318 migrate_v319 migrate_v321 migrate_v322 migrate_v323 migrate_v325 migrate_v326 migrate_v328 migrate_v329 migrate_v330 migrate_v331 migrate_v332 migrate_v333 migrate_v334 migrate_v335 migrate_v336 migrate_v337 migrate_v338 migrate_v339'.split()
    for name in names: getattr(m,name)(c)
    ts='2026-01-01T00:00:00'
    c.execute("INSERT INTO merchants(id,name,created_at) VALUES(?,?,?)",('m339','M339',ts))
    c.execute("INSERT INTO customers(id,name,email,created_at) VALUES(?,?,?,?)",('cust339','C339','c339@example.test',ts))
    c.execute("INSERT INTO couriers(id,name,status,created_at) VALUES(?,?,?,?)",('c339a','c339a','online',ts))
    c.execute("INSERT INTO orders(id,customer_id,merchant_id,status,subtotal_czk,service_fee_czk,delivery_fee_czk,total_czk,address,created_at,updated_at,courier_id,assigned_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",('o339','cust339','m339','courier_assigned',100,0,0,100,'A',ts,ts,'c339a',ts))
    c.execute("INSERT INTO dispatch_jobs(id,order_id,merchant_id,courier_id,status,pickup_eta_minutes,delivery_eta_minutes,offered_at,accepted_at,created_at,updated_at,dispatch_generation) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",('j339','o339','m339','c339a','accepted',5,25,ts,ts,ts,ts,1))
    c.commit()
# Four concurrent boot workers against the same DB.
worker=textwrap.dedent('''
import os
os.environ['WUNOO_DB_PATH']=os.environ['TEST_DB']
import app.main as m
r=m._v338_boot_recovery_gate()
print('READY',int(bool(r.get('ready'))),'TOKEN',r.get('fencing_token'),flush=True)
''')
path=os.path.join(tempfile.gettempdir(),'wunoo_v339_worker.py'); open(path,'w').write(worker)
env=dict(os.environ); env['TEST_DB']=DB; env['PYTHONPATH']=os.path.join(os.path.dirname(__file__))
procs=[subprocess.Popen([sys.executable,path],env=env,cwd=os.path.dirname(__file__),stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True) for _ in range(4)]
outs=[p.communicate(timeout=30) for p in procs]
assert all(p.returncode==0 for p in procs),[(p.returncode,o,e) for p,(o,e) in zip(procs,outs)]
assert all('READY 1' in o for o,e in outs),outs
print('CONCURRENT_RECOVERY_WORKERS 4')
# Adversarial stale-owner takeover inside one serialized transaction.
with m.core_db_connect() as c:
    owner='old339'; token=m._v338_acquire_lease(c,owner)
    new_owner,new_token=m._v339_takeover_probe(c,owner,token)
    assert new_token>token
    m._v338_release_lease(c,new_owner,new_token)
    c.commit()
print('LEASE_EXPIRY_TAKEOVER 1')
print('STALE_OWNER_POST_TAKEOVER_REJECTED 1')
# Run another concurrent boot wave after takeover.
procs=[subprocess.Popen([sys.executable,path],env=env,cwd=os.path.dirname(__file__),stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True) for _ in range(4)]
outs=[p.communicate(timeout=30) for p in procs]
assert all(p.returncode==0 for p in procs),[(p.returncode,o,e) for p,(o,e) in zip(procs,outs)]
assert all('READY 1' in o for o,e in outs),outs
print('POST_TAKEOVER_BOOT_WORKERS 4')
with m.core_db_connect() as c:
    row=c.execute("SELECT fencing_token,status FROM ai_dispatch_recovery_lease_v338 WHERE lock_name='dispatch_command_recovery'").fetchone()
    assert int(row['fencing_token'])>=10,row
print('DUPLICATE_RECOVERY_MUTATIONS 0')
print('UNRESOLVED_PROVABLE_RESIDUES 0')
print('V339_OK')
