# WUNOO v1.385 Candidate — webhook event ID/payload binding

## Change
- Hardened legacy `/api/v059/payment/webhook` duplicate-event handling.
- Exact replay of a previously accepted provider event ID and payload remains idempotent and returns the stored event status.
- Reusing the same provider event ID with a different payload, event type, or payment-intent ID now fails closed with HTTP 409 (`WEBHOOK_EVENT_ID_PAYLOAD_MISMATCH`) rather than being silently acknowledged as a duplicate.
- Existing event record and payment state are not modified by a mismatched replay.

## Verification
- `python -m compileall -q app` — PASS.
- `TEST_V385.py` — PASS: exact replay returns 200/duplicate; changed amount with same event ID returns 409; one event row remains and payment intent stays succeeded.
- `TEST_V384.py` — PASS: two concurrent deliveries of the same event create one event row and finalize the payment once on SQLite.
- `TEST_V383.py`, `TEST_V382.py`, `TEST_V381.py`, `TEST_V380.py`, `TEST_V379.py`, `TEST_V378.py`, `TEST_V377.py`, `TEST_V372.py`, `TEST_V362.py` — PASS when run individually.

## Limitations / status
- SQLite-based tests passed; a live PostgreSQL integration/concurrency test has not been run.
- Candidate only. Not production-approved and not pushed to GitHub.
