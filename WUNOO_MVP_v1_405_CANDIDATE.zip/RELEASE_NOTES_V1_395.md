# WUNOO v1.395 Candidate

## Change

Closed an idempotency gap in the legacy `/api/v049/webhooks/{provider}` handler. Its unique-key conflict/race branch previously acknowledged an event ID as an idempotent duplicate without comparing the incoming payload to the already stored event. The handler now applies the same immutable-event validation to both the ordinary replay path and the uniqueness-conflict path. A missing stored row or mismatched/corrupt payload fails closed with HTTP 409.

## Verification

- `python -m compileall -q app` — PASS
- `TEST_V395.py` — PASS: identical replay accepted; changed payload, changed event type, and corrupt stored payload rejected with HTTP 409.
- `TEST_V394.py` — PASS
- `TEST_V393.py` — PASS
- `TEST_V392.py` — PASS
- `TEST_V391.py` — PASS
- `TEST_V390.py` — PASS
- `TEST_V389.py` — PASS
- `TEST_V388.py` — PASS
- `TEST_V362.py` — PASS
- Final ZIP integrity check — PASS

## Limitations

Tests are local and use the SQLite setup. PostgreSQL integration/concurrency, external payment-provider certification, and production deployment checks have not been run. This is a candidate build, not production approval. No GitHub push or deployment was performed.
