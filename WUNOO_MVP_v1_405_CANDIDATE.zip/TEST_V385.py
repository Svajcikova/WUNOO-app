"""v1.385 regression: a provider event ID cannot be replayed with a different payload."""
import os, sys, json, hmac, hashlib, uuid, tempfile
from pathlib import Path
from fastapi.testclient import TestClient
ROOT=Path(__file__).resolve().parent
os.environ['WUNOO_PAYMENT_WEBHOOK_SECRET']='test-secret-v385'
os.environ['WUNOO_DB_PATH']=os.path.join(tempfile.gettempdir(),'wunoo_v385_'+uuid.uuid4().hex+'.db')
sys.path.insert(0,str(ROOT))
from app import main
main.transition=lambda *args,**kwargs: None
main._v053_log=lambda *args,**kwargs: None
suffix=uuid.uuid4().hex[:10]; uid='u_v385_'+suffix; cid='c_v385_'+suffix; mid='m_v385_'+suffix
order='o_v385_'+suffix; intent='pi_v385_'+suffix; event='evt_v385_'+suffix; stamp=main.now()
def send(client,body):
    raw=json.dumps(body,separators=(',',':')).encode()
    sig='sha256='+hmac.new(b'test-secret-v385',raw,hashlib.sha256).hexdigest()
    return client.post('/api/v059/payment/webhook',content=raw,headers={'X-WUNOO-Signature':sig,'Content-Type':'application/json'})
with TestClient(main.app) as client:
    main.migrate_v049(main.conn()); main.migrate_v059(main.conn())
    with main.conn() as c:
        c.execute("INSERT INTO users(id,email,name,role,active,created_at,password_hash) VALUES(?,?,?,?,?,?,?)",(uid,uid+'@x.test','V385','customer',1,stamp,'x'))
        c.execute("INSERT INTO customers(id,name,email,created_at) VALUES(?,?,?,?)",(cid,'V385 Customer',uid+'@x.test',stamp))
        c.execute("INSERT INTO merchants(id,name,created_at) VALUES(?,?,?)",(mid,'V385 Merchant',stamp))
        c.execute("INSERT INTO orders(id,customer_id,merchant_id,status,subtotal_czk,service_fee_czk,delivery_fee_czk,total_czk,address,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(order,cid,mid,'payment_pending',100,10,10,120,'V385',stamp,stamp))
        c.execute("INSERT INTO payment_intents(id,order_id,amount_czk,currency,status,provider,provider_intent_id,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",(intent,order,120,'CZK','requires_payment_method','test','prov_'+intent,stamp,stamp)); c.commit()
    original={'id':event,'type':'payment_succeeded','payment_intent_id':intent,'amount_czk':120,'currency':'CZK'}
    first=send(client,original); assert first.status_code==200, (first.status_code,first.text)
    replay=send(client,original); assert replay.status_code==200 and replay.json().get('duplicate') is True, (replay.status_code,replay.text)
    changed={**original,'amount_czk':119}
    mismatch=send(client,changed); assert mismatch.status_code==409 and mismatch.json().get('detail',{}).get('code')=='WEBHOOK_EVENT_ID_PAYLOAD_MISMATCH', (mismatch.status_code,mismatch.text)
    with main.conn() as c:
        rows=c.execute('SELECT COUNT(*) n FROM payment_webhook_events WHERE provider_event_id=?',(event,)).fetchone()['n']
        pi=c.execute('SELECT status FROM payment_intents WHERE id=?',(intent,)).fetchone()['status']
    assert rows==1 and pi=='succeeded',(rows,pi)
    print('V385_WEBHOOK_EVENT_ID_PAYLOAD_BINDING_PASS exact_replay=200 changed_payload=409 event_rows=1 intent=succeeded')
