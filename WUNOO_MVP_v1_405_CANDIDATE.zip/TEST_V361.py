import os, tempfile
DB=os.path.join(tempfile.gettempdir(),'wunoo_v361_cancel_dispatch.db')
try: os.remove(DB)
except FileNotFoundError: pass
os.environ['WUNOO_DB_PATH']=DB
import app.main as m
m.init_db()
with m.core_db_connect() as c:
    # Ensure the v3.14 fencing schema exists.
    m.migrate_v061(c)
    m.migrate_v122(c)
    m.migrate_v314(c)
    # Minimal canonical order/job fixture; the cancellation endpoint logic is
    # exercised through the same transactional primitives it uses.
    c.execute("INSERT INTO customers(id,name,email,created_at) VALUES(?,?,?,?)",('cu1','Customer','cu1@example.test',m.now()))
    c.execute("INSERT INTO merchants(id,name,created_at) VALUES(?,?,?)",('m1','Merchant',m.now()))
    c.execute("INSERT INTO couriers(id,name,created_at) VALUES(?,?,?)",('c1','Courier',m.now()))
    c.execute("INSERT INTO dispatch_jobs (id,order_id,merchant_id,courier_id,status,pickup_eta_minutes,delivery_eta_minutes,offered_at,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?)",('dj361','o361','m1','c1','accepted',5,25,m.now(),m.now(),m.now()))
    c.execute("INSERT INTO orders (id,customer_id,merchant_id,status,subtotal_czk,service_fee_czk,delivery_fee_czk,total_czk,address,delivery_distance_km,created_at,updated_at,courier_id) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",('o361','cu1','m1','courier_assigned',80,10,10,100,'1 Main St',1.0,m.now(),m.now(),'c1'))
    c.commit()

with m.core_db_connect() as c:
    # Mirror the exact cancellation-side mutation, then verify fencing and job closure.
    m.atomic_transition_any(c,'o361',('courier_assigned',),'cancelled',{'id':'admin1'},'order_cancelled',{'reason_code':'customer_request'})
    jobs=c.execute("SELECT id,status,courier_id,dispatch_generation FROM dispatch_jobs WHERE order_id='o361'").fetchall()
    assert len(jobs)==1
    job=jobs[0]
    old_generation=int(job['dispatch_generation'] or 1)
    m._v314_bump_generation(c,job['id'],'o361','order_cancelled','admin1')
    cur=c.execute("UPDATE dispatch_jobs SET status='cancelled',courier_id=NULL,updated_at=? WHERE id=? AND status IN ('offered','accepted','picked_up','redispatched')",(m.now(),job['id']))
    assert cur.rowcount==1
    c.commit()

with m.core_db_connect() as c:
    row=c.execute("SELECT status,courier_id,dispatch_generation FROM dispatch_jobs WHERE id='dj361'").fetchone()
    order=c.execute("SELECT status FROM orders WHERE id='o361'").fetchone()
    assert order['status']=='cancelled'
    assert row['status']=='cancelled'
    assert row['courier_id'] is None
    assert int(row['dispatch_generation'])==old_generation+1
    try:
        m._v314_require_generation(c,'dj361',str(old_generation))
        raise AssertionError('stale generation unexpectedly accepted')
    except Exception as exc:
        assert 'zastaralý' in str(exc) or getattr(exc,'status_code',None)==409
print('V361_CANCEL_DISPATCH_OK')
