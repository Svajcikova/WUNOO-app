# WUNOO v1.391 Candidate

## Changes

- Added strict JSON-root validation to signed payment webhook endpoints `/api/v059/payment/webhook`, `/api/v140/payment/webhook`, and `/api/v141/payment/webhook`.
- Valid JSON values that are not objects (`null`, arrays, strings, numbers, booleans) now return HTTP 400 with `WEBHOOK_BODY_INVALID` rather than reaching `.get()` and causing an internal server error.
- The guard runs immediately after JSON parsing and before any event claim, database lookup, or payment-state mutation.
- Added `TEST_V391.py` covering five non-object JSON roots across all three routes (15 checks).

## Verification performed

- `python -m compileall -q app` — PASS.
- `TEST_V391.py` — PASS: all 15 invalid-root requests returned HTTP 400.
- `TEST_V390.py` — PASS.
- `TEST_V389.py` — PASS.
- `TEST_V388.py` — PASS.
- `TEST_V387.py` — PASS.
- `TEST_V386.py` — PASS.
- `TEST_V362.py` — PASS (golden order lifecycle).
- `TEST_V372.py` — PASS.
- `TEST_V377_runtime.py` — PASS.
- `TEST_V378.py` through `TEST_V385.py` — PASS.

## Limitations

This verification was performed using the project's SQLite test setup. A live PostgreSQL integration/concurrency run has not been performed. This is a candidate build, not a production approval. No GitHub push or deployment was performed.
