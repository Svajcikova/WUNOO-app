"""v1.397 regression: refund ledger replay validates immutable refund metadata."""
import os, sys, tempfile, uuid, json
from pathlib import Path
from fastapi import HTTPException
ROOT = Path(__file__).resolve().parent
os.environ['WUNOO_DB_PATH'] = os.path.join(tempfile.gettempdir(), 'wunoo_v397_' + uuid.uuid4().hex + '.db')
sys.path.insert(0, str(ROOT))
from app import main
main.init_db()

def rows_for(c, ref):
    return c.execute("SELECT id,account,metadata_json FROM finance_ledger_entries WHERE entry_type='refund_v234' AND reference=? ORDER BY account", (ref,)).fetchall()

def expect_conflict(fn):
    try:
        fn()
    except HTTPException as exc:
        assert exc.status_code == 409 and exc.detail['code'] == 'REFUND_LEDGER_INCONSISTENT', (exc.status_code, exc.detail)
    else:
        raise AssertionError('inconsistent refund ledger metadata was accepted')

with main.conn() as c:
    order_id, refund_id, provider_ref, amount = 'ord-v397', 'refund-v397', 'provider-ref-v397', 125.50
    main._v234_record_refund_ledger(c, order_id, amount, provider_ref, refund_id)
    c.commit()
    # Exact replay remains idempotent.
    main._v234_record_refund_ledger(c, order_id, amount, provider_ref, refund_id)
    assert len(rows_for(c, provider_ref)) == 2
    # The same ledger columns with a different refund identity must not be accepted.
    changed_refund_id = 'different-refund-id'
    expect_conflict(lambda: main._v234_record_refund_ledger(c, order_id, amount, provider_ref, changed_refund_id))
    # Corrupted metadata on one leg must fail closed too.
    first = rows_for(c, provider_ref)[0]
    meta = json.loads(first['metadata_json'])
    meta['amount_czk'] = 1.00
    c.execute('UPDATE finance_ledger_entries SET metadata_json=? WHERE id=?', (json.dumps(meta), first['id']))
    c.commit()
    expect_conflict(lambda: main._v234_record_refund_ledger(c, order_id, amount, provider_ref, refund_id))
print('V397_REFUND_LEDGER_IMMUTABLE_METADATA_PASS exact_replay=PASS changed_refund_id=409 corrupted_metadata=409')
