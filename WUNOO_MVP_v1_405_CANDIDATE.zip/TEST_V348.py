from app.main import _v348_differential, _v348_reference_step, _v348_candidate_step

# Direct deterministic differential checks, including the complete commit path.
state_r = state_c = 'IDLE'
for event in ['LOCK','LEASE','FENCE','PRE_GATE','RESOLVE','POST_GATE','COMMIT']:
    state_r = _v348_reference_step(state_r, event)
    state_c = _v348_candidate_step(state_c, event)
assert state_r == state_c == 'COMMITTABLE'
state_r = _v348_reference_step(state_r, 'COMMIT')
state_c = _v348_candidate_step(state_c, 'COMMIT')
assert state_r == state_c == 'COMMITTED'

# Invalid transition must fail closed on both implementations.
assert _v348_reference_step('IDLE', 'COMMIT') == 'BLOCKED'
assert _v348_candidate_step('IDLE', 'COMMIT') == 'BLOCKED'

r = _v348_differential()
assert r['passed'] is True
assert r['cases'] == 5000
assert r['failures'] == 0
assert r['event_level_mismatches'] == 0
assert r['double_commits'] == 0
print('V348_OK')
print('CASES', r['cases'])
print('FAILURES', r['failures'])
print('EVENT_LEVEL_MISMATCHES', r['event_level_mismatches'])
print('DOUBLE_COMMITS', r['double_commits'])
