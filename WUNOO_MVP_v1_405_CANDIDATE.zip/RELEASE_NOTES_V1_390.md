# WUNOO v1.390 Candidate — consistent payment webhook amount validation

## Changes
- Hardened `/api/v059/payment/webhook` and `/api/v140/payment/webhook` amount parsing.
- Both endpoints now reject malformed numeric values, booleans, `NaN`, and positive/negative infinity with HTTP 400 and `PAYMENT_AMOUNT_INVALID`.
- Valid finite amounts that do not match the server-side payment amount continue to be rejected as conflicts.
- Invalid amount claims do not change payment intent state or leave a claimed webhook event behind.
- Validation now matches the stricter behavior already implemented for `/api/v141/payment/webhook` in v1.389.

## Verification
- `python -m compileall -q app` — PASS.
- `TEST_V390.py` — PASS: four invalid amount cases on each of v059 and v140; including `true` against a CZK 1.00 payment, which would otherwise coerce to 1.0; all returned HTTP 400 with no state mutation and no persisted event.
- `TEST_V389.py` — PASS: v141 malformed amount guard, replay binding, and terminal-state checks.
- `TEST_V388.py` — PASS: v059 terminal-state protections.
- `TEST_V386.py` — PASS: v140 webhook duplicate and terminal-state protections.
- `TEST_V384.py` — PASS: concurrent duplicate webhook deduplication on SQLite.
- `TEST_V372.py` — PASS: legacy webhook amount/currency guard.
- `TEST_V362.py` — PASS: golden order lifecycle including settlement and refund.
- Candidate source was extracted from the ZIP and tests were run against the extracted files; archive integrity check — PASS.

## Limitations
- These tests run against the project's SQLite test setup. A live PostgreSQL integration test has not been performed.
- This is a candidate build, not production-approved; changes have not been pushed to GitHub.
