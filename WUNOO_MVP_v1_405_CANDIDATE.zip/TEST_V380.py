import os, sys, uuid, tempfile
DB=os.path.join(tempfile.gettempdir(),'wunoo_v380_'+uuid.uuid4().hex+'.db')
os.environ['WUNOO_DB_PATH']=DB
sys.path.insert(0,os.path.dirname(__file__))
from app import main
main.init_db()
with main.conn() as c:
    main.migrate_v049(c); main.migrate_v064(c); main.migrate_v120(c); main.migrate_v122(c); c.commit()
ts=main.now(); uid='u380_'+uuid.uuid4().hex[:8]; cid='cu380_'+uuid.uuid4().hex[:8]; mid='m380_'+uuid.uuid4().hex[:8]
oid='o380_'+uuid.uuid4().hex[:8]; pid='p380_'+uuid.uuid4().hex[:8]
with main.conn() as c:
    c.execute('INSERT INTO users(id,email,name,role,active,created_at,password_hash) VALUES(?,?,?,?,?,?,?)',(uid,uid+'@test.invalid','V380 Admin','admin',1,ts,'x'))
    c.execute('INSERT INTO customers(id,name,email,created_at) VALUES(?,?,?,?)',(cid,'V380 Customer',uid+'@test.invalid',ts))
    c.execute('INSERT INTO merchants(id,name,created_at) VALUES(?,?,?)',(mid,'V380 Merchant',ts))
    c.execute('INSERT INTO orders(id,customer_id,merchant_id,status,subtotal_czk,service_fee_czk,delivery_fee_czk,total_czk,address,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(oid,cid,mid,'delivered',100,0,0,100,'V380',ts,ts))
    c.execute('INSERT INTO payments(id,order_id,provider_payment_id,amount_czk,status,created_at) VALUES(?,?,?,?,?,?)',(pid,oid,'prov_'+pid,100,'captured',ts))
    main.insert_refund(c,'prior_'+uuid.uuid4().hex[:8],oid,pid,60,'cross_version','processed','pr_'+uuid.uuid4().hex[:8])
    c.commit()
old=main.current_user; main.current_user=lambda auth:{'id':uid,'role':'admin'}
try:
    result=main.refund(oid,None)
    assert abs(float(result['amount_czk'])-40.0)<1e-9, result
    with main.conn() as c:
        sums=c.execute("SELECT SUM(amount_czk) n FROM refunds WHERE order_id=? AND status IN ('pending','processed','succeeded')",(oid,)).fetchone()['n']
        assert abs(float(sums)-100.0)<1e-9, sums
    print('V380_FULL_REFUND_CROSS_VERSION_CAP_PASS prior_processed=60 new_refund=40 total=100')
finally:
    main.current_user=old
    with main.conn() as c:
        c.execute('DELETE FROM finance_ledger_entries WHERE order_id=?',(oid,)); c.execute('DELETE FROM refunds WHERE order_id=?',(oid,)); c.execute('DELETE FROM payments WHERE order_id=?',(oid,)); c.execute('DELETE FROM orders WHERE id=?',(oid,)); c.execute('DELETE FROM customers WHERE id=?',(cid,)); c.execute('DELETE FROM merchants WHERE id=?',(mid,)); c.execute('DELETE FROM users WHERE id=?',(uid,)); c.commit()
    try: os.remove(DB)
    except OSError: pass
source=open(os.path.join(os.path.dirname(__file__),'app','main.py'),encoding='utf-8').read()
route=source.split('@app.post("/api/orders/{order_id}/refund")',1)[1].split('@app.post("/api/orders/{order_id}/merchant-accept")',1)[0]
assert "status IN ('pending','processed','succeeded')" in route
