import os, tempfile, importlib.util, sqlite3
DB=os.path.join(tempfile.gettempdir(),'wunoo_v359_pickup_api.db')
try: os.remove(DB)
except FileNotFoundError: pass
os.environ['WUNOO_DB_PATH']=DB
spec=importlib.util.spec_from_file_location('m','app/main.py'); m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
m.init_db()
with m.closing(m.conn()) as _mc: m._run_all_migrations(_mc)
# Verify the production endpoint source no longer hardcodes legacy assigned.
src=open('app/main.py',encoding='utf-8').read()
assert 'transition(c, order_id, "assigned", "picked_up"' not in src
# Direct transition conformance for both canonical and legacy predecessors.
c=m.conn(); c.execute('PRAGMA foreign_keys=OFF'); c.execute("CREATE TABLE IF NOT EXISTS orders (id TEXT PRIMARY KEY,status TEXT,courier_id TEXT,updated_at TEXT,picked_up_at TEXT)")
c.execute("CREATE TABLE IF NOT EXISTS events (id TEXT PRIMARY KEY,order_id TEXT,type TEXT,actor_user_id TEXT,payload_json TEXT,created_at TEXT)")
c.execute("CREATE TABLE IF NOT EXISTS state_transition_audit (id TEXT PRIMARY KEY,entity_type TEXT,entity_id TEXT,from_state TEXT,to_state TEXT,actor_id TEXT,idempotency_key TEXT,created_at TEXT)")
# Existing app schema is expected in normal runtime; this isolated test only checks the transition contract.
# Use a minimal actor compatible with transition().
c.execute("INSERT INTO orders(id,customer_id,merchant_id,status,subtotal_czk,service_fee_czk,delivery_fee_czk,total_czk,address,courier_id,created_at,updated_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",('o359','cust359','merch359','courier_assigned',100,0,0,100,'A','c359',m.now(),m.now()))
actor={'id':'c359','role':'courier','courier_id':'c359'}
m.transition(c,'o359','courier_assigned','picked_up',actor,'pickup_completed',{'courier_id':'c359'})
row=c.execute("SELECT status FROM orders WHERE id='o359'").fetchone(); assert row['status']=='picked_up'
print('V359_CANONICAL_PICKUP_ENDPOINT_GUARD PASS')
print('COURIER_ASSIGNED_TO_PICKED_UP PASS')
