import os, sys, uuid, tempfile
DB=os.path.join(tempfile.gettempdir(), 'wunoo_v379_'+uuid.uuid4().hex+'.db')
os.environ['WUNOO_DB_PATH']=DB
sys.path.insert(0, os.path.dirname(__file__))
from app import main
main.init_db()
with main.conn() as c:
    main.migrate_v049(c); main.migrate_v112(c)
    c.commit()
ts=main.now(); cid='cu379_'+uuid.uuid4().hex[:8]; mid='m379_'+uuid.uuid4().hex[:8]
orders=[('o379a_'+uuid.uuid4().hex[:8],100,30),('o379b_'+uuid.uuid4().hex[:8],100,110)]
with main.conn() as c:
    c.execute('INSERT INTO customers(id,name,email,created_at) VALUES(?,?,?,?)',(cid,'V379 Customer',cid+'@test.invalid',ts))
    c.execute('INSERT INTO merchants(id,name,created_at) VALUES(?,?,?)',(mid,'V379 Merchant',ts))
    for oid, paid, pending in orders:
        c.execute('INSERT INTO orders(id,customer_id,merchant_id,status,subtotal_czk,service_fee_czk,delivery_fee_czk,total_czk,address,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)',(oid,cid,mid,'delivered',paid,0,0,paid,'V379',ts,ts))
        pid='p379_'+uuid.uuid4().hex[:8]
        c.execute('INSERT INTO payments(id,order_id,provider_payment_id,amount_czk,status,created_at) VALUES(?,?,?,?,?,?)',(pid,oid,'prov_'+pid,paid,'captured',ts))
        main.insert_refund(c,'r379_'+uuid.uuid4().hex[:8],oid,pid,pending,'v379-test','pending','pr379_'+uuid.uuid4().hex[:8])
    c.commit()
with main.conn() as c:
    recon=main._v049_reconcile_order(c,orders[0][0])
    assert float(recon['refunded_amount_czk']) == 30.0, recon
    result=main._v112_run(c)
    bound=[x for x in result['checks'] if x['check']=='REFUND_BOUND'][0]
    assert bound['valid'] is False, result
    assert bound['details']['violations'] >= 1, bound
print('V379_PENDING_REFUND_RECONCILIATION_PASS pending_in_reconciliation=True over_cap_detected=True')
with main.conn() as c:
    for oid,_,_ in orders:
        c.execute('DELETE FROM finance_ledger_entries WHERE order_id=?',(oid,))
        c.execute('DELETE FROM refunds WHERE order_id=?',(oid,))
        c.execute('DELETE FROM payments WHERE order_id=?',(oid,))
        c.execute('DELETE FROM orders WHERE id=?',(oid,))
    c.execute('DELETE FROM customers WHERE id=?',(cid,)); c.execute('DELETE FROM merchants WHERE id=?',(mid,)); c.commit()
try: os.remove(DB)
except OSError: pass
