import os,tempfile
DB=os.path.join(tempfile.gettempdir(),'wunoo_v335_recovery.db')
os.environ['WUNOO_DB_PATH']=DB
try: os.remove(DB)
except FileNotFoundError: pass
import app.main as m
m.init_db()
with m.core_db_connect() as c:
    for name in 'migrate_v046 migrate_v052 migrate_v053 migrate_v061 migrate_v119 migrate_v120 migrate_v121 migrate_v122 migrate_v310 migrate_v311 migrate_v312 migrate_v313 migrate_v314 migrate_v315 migrate_v316 migrate_v318 migrate_v319 migrate_v321 migrate_v322 migrate_v323 migrate_v325 migrate_v326 migrate_v328 migrate_v329 migrate_v330 migrate_v331 migrate_v332 migrate_v333 migrate_v334 migrate_v335'.split(): getattr(m,name)(c)
    ts='2026-01-01T00:00:00'
    c.execute("INSERT INTO merchants(id,name,created_at) VALUES(?,?,?)",('m335','M335',ts))
    c.execute("INSERT INTO customers(id,name,email,created_at) VALUES(?,?,?,?)",('cust335','C335','c335@example.test',ts))
    for cid in ('c335a','c335b','c335c'):
        c.execute("INSERT INTO couriers(id,name,status,created_at) VALUES(?,?,?,?)",(cid,cid,'online',ts))
    c.execute("INSERT INTO orders(id,customer_id,merchant_id,status,subtotal_czk,service_fee_czk,delivery_fee_czk,total_czk,address,created_at,updated_at,courier_id,assigned_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",('o335','cust335','m335','courier_assigned',100,0,0,100,'A',ts,ts,'c335a',ts))
    c.execute("INSERT INTO dispatch_jobs(id,order_id,merchant_id,courier_id,status,pickup_eta_minutes,delivery_eta_minutes,offered_at,accepted_at,created_at,updated_at,dispatch_generation) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",('j335','o335','m335','c335a','accepted',5,25,ts,ts,ts,ts,1))
    c.commit()
actor={'id':'ops335','role':'ops_agent'}
# 1) Healthy command through v335 remains compatible and mutates once.
with m.core_db_connect() as c:
    r=m._v335_resolve_order(c,'o335'); c.commit()
assert r['passed'] and r['resolved']==0
with m.core_db_connect() as c:
    r=m._v334_command(c,'key335','o335',actor,'operator_reassign',{'courier_id':'c335b','reason':'normal'},'1'); c.commit()
assert not r['replayed'] and r['postcondition']['passed']
# 2) Exact replay through v335 is non-mutating.
with m.core_db_connect() as c:
    before=c.execute("SELECT dispatch_generation,courier_id FROM dispatch_jobs WHERE id='j335'").fetchone()
    r2=m._v335_resolve_order(c,'o335'); c.commit()
    after=c.execute("SELECT dispatch_generation,courier_id FROM dispatch_jobs WHERE id='j335'").fetchone()
assert r2['passed'] and before['dispatch_generation']==after['dispatch_generation'] and before['courier_id']==after['courier_id']
# 3) Simulate crash residue: pending journal + generation fence + completed operator reassignment state,
# but no postcondition/journal completion. Resolution must infer only from exact generation audit evidence.
with m.core_db_connect() as c:
    # move b -> c using real operator override, then create the pending command as if it crashed after mutation
    c.execute("INSERT INTO ai_dispatch_command_journal_v312(id,request_key,order_id,actor_id,command_type,status,response_json,evidence_sha256,created_at,completed_at,request_payload_sha256) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
              ('pending335','pending335','o335','ops335','operator_reassign','pending','{}','pending','2026-01-01T02:00:00',None,m._v331_payload_hash({'courier_id':'c335c','reason':'crash'})))
    c.execute("INSERT INTO ai_dispatch_generation_fence_v332(id,request_key,order_id,actor_id,command_type,expected_generation,created_at) VALUES(?,?,?,?,?,?,?)",
              ('fence335','pending335','o335','ops335','operator_reassign',2,'2026-01-01T02:00:00'))
    # Perform only the underlying mutation that the command would have performed.
    m._v311_operator_reassign_v313(c,'o335','c335c',actor,'crash')
    c.commit()
with m.core_db_connect() as c:
    before=c.execute("SELECT dispatch_generation,courier_id FROM dispatch_jobs WHERE id='j335'").fetchone()
    rec=m._v335_resolve_order(c,'o335'); c.commit()
    after=c.execute("SELECT dispatch_generation,courier_id FROM dispatch_jobs WHERE id='j335'").fetchone()
    j=c.execute("SELECT status FROM ai_dispatch_command_journal_v312 WHERE id='pending335'").fetchone()
assert rec['passed'] and rec['resolved']>=1 and j['status']=='completed'
assert before['dispatch_generation']==after['dispatch_generation'] and before['courier_id']==after['courier_id']
assert any(x.get('action')=='RESOLVE_ORPHAN_PENDING' and x.get('result')=='RESOLVED' for x in rec['results'])
# 4) Resolution is idempotent and does not bump generation again.
with m.core_db_connect() as c:
    before=c.execute("SELECT dispatch_generation,courier_id FROM dispatch_jobs WHERE id='j335'").fetchone()
    rec2=m._v335_resolve_order(c,'o335'); c.commit()
    after=c.execute("SELECT dispatch_generation,courier_id FROM dispatch_jobs WHERE id='j335'").fetchone()
assert rec2['passed'] and before['dispatch_generation']==after['dispatch_generation'] and before['courier_id']==after['courier_id']
# 5) Unprovable orphan remains blocked: missing fence proof means no mutation and journal stays pending.
with m.core_db_connect() as c:
    c.execute("INSERT INTO ai_dispatch_command_journal_v312(id,request_key,order_id,actor_id,command_type,status,response_json,evidence_sha256,created_at,completed_at,request_payload_sha256) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
              ('blocked335','blocked335','o335','ops335','operator_reassign','pending','{}','blocked','2026-01-01T03:00:00',None,m._v331_payload_hash({'courier_id':'c335a','reason':'unknown'})))
    c.commit()
with m.core_db_connect() as c:
    before=c.execute("SELECT dispatch_generation,courier_id FROM dispatch_jobs WHERE id='j335'").fetchone()
    rec3=m._v335_resolve_order(c,'o335'); c.commit()
    after=c.execute("SELECT dispatch_generation,courier_id FROM dispatch_jobs WHERE id='j335'").fetchone()
    j=c.execute("SELECT status FROM ai_dispatch_command_journal_v312 WHERE id='blocked335'").fetchone()
assert not rec3['passed'] and j['status']=='pending'
assert before['dispatch_generation']==after['dispatch_generation'] and before['courier_id']==after['courier_id']
print('V335_OK')
print('NORMAL_COMMAND_COMPATIBLE 1')
print('EXACT_REPLAY_NON_MUTATING 1')
print('CRASH_RESIDUE_RESOLVED 1')
print('RESOLUTION_IDEMPOTENT 1')
print('UNPROVABLE_ORPHAN_BLOCKED 1')
print('UNRESOLVED_MUTATIONS 0')
