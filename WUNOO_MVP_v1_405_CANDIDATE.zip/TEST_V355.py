import os, tempfile
DB=os.path.join(tempfile.gettempdir(),'wunoo_v355_clean.db')
try: os.remove(DB)
except FileNotFoundError: pass
os.environ['WUNOO_DB_PATH']=DB
from app.main import *
import app.main as m
m.init_db()
with m.core_db_connect() as c:
    for fn in (m.migrate_v312,m.migrate_v333,m.migrate_v334,m.migrate_v335,m.migrate_v336,m.migrate_v337,m.migrate_v338,m.migrate_v341,m.migrate_v350,m.migrate_v351,m.migrate_v352,m.migrate_v353,m.migrate_v354,m.migrate_v355): fn(c)
    m._v336_boot_record(c,'seed_v355','READY',True,{'test_fixture':True})
    c.commit()
with m.core_db_connect() as c:
    c.execute("INSERT INTO ai_dispatch_recovery_observability_v354(id,run_id,cycle,active_leases,pending_journal,unresolved_recovery,active_locks,max_fencing_token,audit_rows,residue_free,monotonic_token,leak_detected,passed,detail_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", ('seedobs_'+('354' if fn=='TEST_V354.py' else '355'),'seedobs',-1,0,0,0,0,0,0,1,1,0,1,'{}',m.datetime.now(m.timezone.utc).isoformat())); c.commit()
r=m._v354_observability(cycles=2)
assert r['passed'] is True
h=m._v355_health_gate(phase='POST_RECOVERY', require_observability=True)
assert h['passed'] is True
assert h['decision']=='HEALTHY'
assert h['blocked'] is False
assert h['reason_codes']==[]
assert h['snapshot']['active_leases']==0
assert h['snapshot']['pending_journal']==0
assert h['snapshot']['unresolved_recovery']==0
assert h['snapshot']['boot_ready'] is True
assert h['snapshot']['observability_healthy'] is True
print('V355_OK')
print('DECISION',h['decision'])
print('BLOCKED',h['blocked'])
print('REASONS',len(h['reason_codes']))
print('ACTIVE_LEASES',h['snapshot']['active_leases'])
print('PENDING_JOURNAL',h['snapshot']['pending_journal'])
print('UNRESOLVED_RECOVERY',h['snapshot']['unresolved_recovery'])
print('BOOT_READY',h['snapshot']['boot_ready'])
print('OBSERVABILITY_HEALTHY',h['snapshot']['observability_healthy'])
