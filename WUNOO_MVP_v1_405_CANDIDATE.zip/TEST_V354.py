import os, tempfile
DB=os.path.join(tempfile.gettempdir(),'wunoo_v354_clean.db')
try: os.remove(DB)
except FileNotFoundError: pass
os.environ['WUNOO_DB_PATH']=DB
from app.main import *
import app.main as m
m.init_db()
with m.core_db_connect() as c:
    for fn in (m.migrate_v312,m.migrate_v333,m.migrate_v334,m.migrate_v335,m.migrate_v336,m.migrate_v337,m.migrate_v338,m.migrate_v341,m.migrate_v350,m.migrate_v351,m.migrate_v352,m.migrate_v353,m.migrate_v354): fn(c)
    # Explicit healthy boot baseline: the observability test must not depend on a prior test run.
    m._v336_boot_record(c,'seed_v354','READY',True,{'test_fixture':True})
    c.commit()
with m.core_db_connect() as c:
    c.execute("INSERT INTO ai_dispatch_recovery_observability_v354(id,run_id,cycle,active_leases,pending_journal,unresolved_recovery,active_locks,max_fencing_token,audit_rows,residue_free,monotonic_token,leak_detected,passed,detail_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", ('seedobs_'+('354' if fn=='TEST_V354.py' else '355'),'seedobs',-1,0,0,0,0,0,0,1,1,0,1,'{}',m.datetime.now(m.timezone.utc).isoformat())); c.commit()
r=m._v354_observability(cycles=4)
assert r['passed'] is True
assert r['cycles']==4
assert r['failures']==0
assert r['leaks_detected']==0
assert r['residue_free_cycles']==4
assert r['monotonic_token'] is True
print('V354_OK')
print('CYCLES',r['cycles'])
print('FAILURES',r['failures'])
print('LEAKS_DETECTED',r['leaks_detected'])
print('RESIDUE_FREE_CYCLES',r['residue_free_cycles'])
print('MONOTONIC_TOKEN',r['monotonic_token'])
