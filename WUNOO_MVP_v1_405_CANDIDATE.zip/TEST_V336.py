import os,tempfile,shutil
DB=os.path.join(tempfile.gettempdir(),'wunoo_v336_boot.db')
try: os.remove(DB)
except FileNotFoundError: pass
os.environ['WUNOO_DB_PATH']=DB
import app.main as m
m.init_db()
with m.core_db_connect() as c:
    # Explicit current migration chain relevant to dispatch recovery.
    for name in 'migrate_v046 migrate_v052 migrate_v053 migrate_v061 migrate_v119 migrate_v120 migrate_v121 migrate_v122 migrate_v310 migrate_v311 migrate_v312 migrate_v313 migrate_v314 migrate_v315 migrate_v316 migrate_v318 migrate_v319 migrate_v321 migrate_v322 migrate_v323 migrate_v325 migrate_v326 migrate_v328 migrate_v329 migrate_v330 migrate_v331 migrate_v332 migrate_v333 migrate_v334 migrate_v335 migrate_v336'.split(): getattr(m,name)(c)
    ts='2026-01-01T00:00:00'
    c.execute("INSERT INTO merchants(id,name,created_at) VALUES(?,?,?)",('m336','M336',ts))
    c.execute("INSERT INTO customers(id,name,email,created_at) VALUES(?,?,?,?)",('cust336','C336','c336@example.test',ts))
    c.execute("INSERT INTO couriers(id,name,status,created_at) VALUES(?,?,?,?)",('c336a','c336a','online',ts))
    c.execute("INSERT INTO orders(id,customer_id,merchant_id,status,subtotal_czk,service_fee_czk,delivery_fee_czk,total_czk,address,created_at,updated_at,courier_id,assigned_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",('o336','cust336','m336','courier_assigned',100,0,0,100,'A',ts,ts,'c336a',ts))
    c.execute("INSERT INTO dispatch_jobs(id,order_id,merchant_id,courier_id,status,pickup_eta_minutes,delivery_eta_minutes,offered_at,accepted_at,created_at,updated_at,dispatch_generation) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",('j336','o336','m336','c336a','accepted',5,25,ts,ts,ts,ts,1))
    c.commit()
# Healthy empty journal boot passes.
r=m._v336_boot_recovery_gate(); assert r['ready'],r
print('BOOT_EMPTY_READY 1')
# Create provable crash residue like v335 and verify boot resolves it.
actor={'id':'ops336','role':'ops_agent'}
with m.core_db_connect() as c:
    c.execute("INSERT INTO ai_dispatch_command_journal_v312(id,request_key,order_id,actor_id,command_type,status,response_json,evidence_sha256,created_at,completed_at,request_payload_sha256) VALUES(?,?,?,?,?,?,?,?,?,?,?)",('pending336','pending336','o336','ops336','operator_reassign','pending','{}','pending',ts,None,m._v331_payload_hash({'courier_id':'c336a','reason':'boot-crash'})))
    c.execute("INSERT INTO ai_dispatch_generation_fence_v332(id,request_key,order_id,actor_id,command_type,expected_generation,created_at) VALUES(?,?,?,?,?,?,?)",('fence336','pending336','o336','ops336','operator_reassign',1,ts))
    # Simulate mutation from c336a -> c336a is invalid because no actual reassignment. Use direct
    # operator helper with a new courier so generation advances to 2 and durable audit exists.
    c.execute("INSERT INTO couriers(id,name,status,created_at) VALUES(?,?,?,?)",('c336b','c336b','online',ts))
    m._v311_operator_reassign_v313(c,'o336','c336b',actor,'boot-crash')
    c.commit()
r2=m._v336_boot_recovery_gate(); assert r2['ready'],r2
with m.core_db_connect() as c:
    j=c.execute("SELECT status FROM ai_dispatch_command_journal_v312 WHERE id='pending336'").fetchone()
    gen=c.execute("SELECT dispatch_generation,courier_id FROM dispatch_jobs WHERE id='j336'").fetchone()
assert j['status']=='completed' and int(gen['dispatch_generation'])==2 and gen['courier_id']=='c336b'
print('AUTOMATIC_CRASH_RESOLUTION 1')
print('NO_DOUBLE_GENERATION_BUMP 1')
# Unprovable pending blocks boot and must not mutate.
with m.core_db_connect() as c:
    c.execute("INSERT INTO ai_dispatch_command_journal_v312(id,request_key,order_id,actor_id,command_type,status,response_json,evidence_sha256,created_at,completed_at,request_payload_sha256) VALUES(?,?,?,?,?,?,?,?,?,?,?)",('blocked336','blocked336','o336','ops336','operator_reassign','pending','{}','blocked', '2026-01-01T03:00:00',None,m._v331_payload_hash({'courier_id':'c336a','reason':'unknown'})))
    c.commit()
r3=m._v336_boot_recovery_gate(); assert not r3['ready'],r3
with m.core_db_connect() as c:
    j=c.execute("SELECT status FROM ai_dispatch_command_journal_v312 WHERE id='blocked336'").fetchone()
    gen=c.execute("SELECT dispatch_generation,courier_id FROM dispatch_jobs WHERE id='j336'").fetchone()
assert j['status']=='pending' and int(gen['dispatch_generation'])==2 and gen['courier_id']=='c336b'
print('UNPROVABLE_ORPHAN_BLOCKS_BOOT 1')
print('UNRESOLVED_MUTATIONS 0')
print('V336_OK')
