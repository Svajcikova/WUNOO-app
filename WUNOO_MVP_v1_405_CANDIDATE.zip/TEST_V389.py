"""v1.389 regression: v1.141 webhook immutable event binding and terminal payment states."""
import os, sys, json, hmac, hashlib, tempfile, uuid
from pathlib import Path
from fastapi.testclient import TestClient
ROOT=Path(__file__).resolve().parent
os.environ['WUNOO_PAYMENT_WEBHOOK_SECRET']='test-secret-v389'
os.environ['WUNOO_DB_PATH']=os.path.join(tempfile.gettempdir(),'wunoo_v389_'+uuid.uuid4().hex+'.db')
sys.path.insert(0,str(ROOT))
from app import main
main.transition=lambda *args,**kwargs: None
main.emit=lambda *args,**kwargs: None
# Keep this regression focused on webhook state handling; finality accounting has its own tests.
main._v141_capture_finality=lambda c,pi,provider_event_id=None,actor_id='system': ({'id':'fin_test','payment_id':'pay_test','amount_czk':float(pi['locked_amount_czk'] or pi['amount_czk']),'currency':pi['locked_currency'] or pi['currency'],'ledger_debit_czk':float(pi['locked_amount_czk'] or pi['amount_czk']),'ledger_credit_czk':float(pi['locked_amount_czk'] or pi['amount_czk'])},False)
suffix=uuid.uuid4().hex[:10]; cid='c_v389_'+suffix; mid='m_v389_'+suffix; stamp=main.now()
def send(client,body):
    raw=json.dumps(body,separators=(',',':')).encode()
    sig='sha256='+hmac.new(b'test-secret-v389',raw,hashlib.sha256).hexdigest()
    return client.post('/api/v141/payment/webhook',content=raw,headers={'X-WUNOO-Signature':sig,'Content-Type':'application/json'})
with TestClient(main.app) as client:
    with main.conn() as c:
        main.migrate_v049(c); main.migrate_v059(c); main.migrate_v140(c); main.migrate_v141(c)
        c.execute("INSERT INTO customers(id,name,email,created_at) VALUES(?,?,?,?)",(cid,'V389 Customer',cid+'@x.test',stamp))
        c.execute("INSERT INTO merchants(id,name,created_at) VALUES(?,?,?)",(mid,'V389 Merchant',stamp))
        for suffix2,status in [('success','payment_pending'),('terminal','payment_pending')]:
            oid='o_v389_'+suffix2+'_'+suffix; iid='pi_v389_'+suffix2+'_'+suffix
            c.execute("INSERT INTO orders(id,customer_id,merchant_id,status,subtotal_czk,service_fee_czk,delivery_fee_czk,total_czk,address,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(oid,cid,mid,status,100,10,10,120,'V389',stamp,stamp))
            c.execute("INSERT INTO payment_intents(id,order_id,amount_czk,currency,status,provider,provider_intent_id,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",(iid,oid,120,'CZK','requires_payment_method','test','prov_'+iid,stamp,stamp))
        c.commit()
    success_intent='pi_v389_success_'+suffix
    # Malformed, boolean and non-finite amounts must be a client error, not a 500,
    # and must not claim/store the event or mutate the payment intent.
    invalid_intent='pi_v389_terminal_'+suffix
    for idx, bad_amount in enumerate(['not-a-number', True, float('inf'), float('nan')]):
        invalid_body={'id':f'evt_v389_invalid_amount_{idx}_'+suffix,'type':'payment_succeeded','payment_intent_id':invalid_intent,'amount_czk':bad_amount,'currency':'CZK'}
        invalid_response=send(client,invalid_body)
        assert invalid_response.status_code==400 and invalid_response.json().get('detail',{}).get('code')=='PAYMENT_AMOUNT_INVALID',(bad_amount,invalid_response.status_code,invalid_response.text)
    with main.conn() as c:
        unchanged=c.execute('SELECT status FROM payment_intents WHERE id=?',(invalid_intent,)).fetchone()['status']
        invalid_events=c.execute('SELECT COUNT(*) n FROM payment_webhook_events WHERE provider_event_id LIKE ?',('evt_v389_invalid_amount_%_'+suffix,)).fetchone()['n']
    assert unchanged=='requires_payment_method' and invalid_events==0,(unchanged,invalid_events)
    original={'id':'evt_v389_success_'+suffix,'type':'payment_succeeded','payment_intent_id':success_intent,'amount_czk':120,'currency':'CZK'}
    first=send(client,original); assert first.status_code==200,(first.status_code,first.text)
    replay=send(client,original); assert replay.status_code==200 and replay.json().get('duplicate') is True,(replay.status_code,replay.text)
    altered=send(client,{**original,'amount_czk':119}); assert altered.status_code==409 and altered.json().get('detail',{}).get('code')=='WEBHOOK_EVENT_ID_PAYLOAD_MISMATCH',(altered.status_code,altered.text)
    late=send(client,{'id':'evt_v389_late_'+suffix,'type':'payment_failed','payment_intent_id':success_intent,'amount_czk':120,'currency':'CZK'})
    assert late.status_code==200 and late.json().get('ignored') is True,(late.status_code,late.text)
    terminal_intent='pi_v389_terminal_'+suffix
    failed=send(client,{'id':'evt_v389_failed_'+suffix,'type':'payment_failed','payment_intent_id':terminal_intent,'amount_czk':120,'currency':'CZK'})
    assert failed.status_code==200 and failed.json().get('status')=='failed',(failed.status_code,failed.text)
    contradictory=send(client,{'id':'evt_v389_cancel_'+suffix,'type':'payment_cancelled','payment_intent_id':terminal_intent,'amount_czk':120,'currency':'CZK'})
    assert contradictory.status_code==409 and contradictory.json().get('detail',{}).get('code')=='PAYMENT_TERMINAL_STATE_CONFLICT',(contradictory.status_code,contradictory.text)
    with main.conn() as c:
        success_status=c.execute('SELECT status FROM payment_intents WHERE id=?',(success_intent,)).fetchone()['status']
        terminal_status=c.execute('SELECT status FROM payment_intents WHERE id=?',(terminal_intent,)).fetchone()['status']
        event_count=c.execute('SELECT COUNT(*) n FROM payment_webhook_events WHERE provider_event_id=?',(original['id'],)).fetchone()['n']
    assert success_status=='succeeded' and terminal_status=='failed' and event_count==1,(success_status,terminal_status,event_count)
    print('V389_V141_WEBHOOK_IMMUTABLE_EVENT_TERMINAL_GUARD_PASS invalid_amounts=400 no_mutation=true exact_replay=200 changed_payload=409 late_failure=ignored failed_to_cancelled=409')
