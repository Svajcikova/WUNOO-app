"""v1.381 concurrency regression: cross-version refunds and settlement single-flight."""
import os, sys, tempfile, uuid, concurrent.futures
from fastapi import HTTPException

DB = os.path.join(tempfile.gettempdir(), "wunoo_v381_" + uuid.uuid4().hex + ".db")
os.environ["WUNOO_DB_PATH"] = DB
sys.path.insert(0, os.path.dirname(__file__))
from app import main

main.init_db()
with main.conn() as c:
    for migrate in (main.migrate_v049, main.migrate_v052, main.migrate_v062,
                    main.migrate_v064, main.migrate_v120, main.migrate_v122):
        migrate(c)
    c.commit()

ts = main.now()
uid = "v381_admin_" + uuid.uuid4().hex[:8]
cid = "v381_customer_" + uuid.uuid4().hex[:8]
mid = "v381_merchant_" + uuid.uuid4().hex[:8]
refund_oid = "v381_refund_" + uuid.uuid4().hex[:8]
settle_oid = "v381_settle_" + uuid.uuid4().hex[:8]
with main.conn() as c:
    c.execute("INSERT INTO users(id,email,name,role,active,created_at,password_hash) VALUES(?,?,?,?,?,?,?)",
              (uid, uid + "@test.invalid", "V381 Admin", "admin", 1, ts, "x"))
    c.execute("INSERT INTO customers(id,name,email,created_at) VALUES(?,?,?,?)",
              (cid, "V381 Customer", uid + "@test.invalid", ts))
    c.execute("INSERT INTO merchants(id,name,created_at) VALUES(?,?,?)", (mid, "V381 Merchant", ts))
    for oid in (refund_oid, settle_oid):
        c.execute("INSERT INTO orders(id,customer_id,merchant_id,status,subtotal_czk,service_fee_czk,delivery_fee_czk,total_czk,address,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
                  (oid, cid, mid, "delivered", 100, 0, 0, 100, "V381 test", ts, ts))
    c.execute("INSERT INTO payments(id,order_id,provider_payment_id,amount_czk,status,created_at) VALUES(?,?,?,?,?,?)",
              ("pay_" + refund_oid, refund_oid, "prov_" + refund_oid, 100, "captured", ts))
    c.commit()

original_current_user = main.current_user
main.current_user = lambda _auth: {"id": uid, "role": "admin"}

def attempt_refund(_):
    try:
        return ("ok", main.v049_partial_refund(refund_oid, {"amount_czk": 60}, None))
    except HTTPException as exc:
        return ("http", exc.status_code)

def attempt_settlement(n):
    try:
        return ("ok", main.v062_settlement_run({"order_id": settle_oid}, None, "v381-settlement-key-" + str(n)))
    except Exception as exc:
        return ("error", type(exc).__name__, str(exc))

try:
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        refund_results = list(pool.map(attempt_refund, (1, 2)))
    with main.conn() as c:
        refund_total = float(c.execute("SELECT COALESCE(SUM(amount_czk),0) n FROM refunds WHERE order_id=? AND status IN ('pending','processed','succeeded')", (refund_oid,)).fetchone()["n"])
    assert sum(x[0] == "ok" for x in refund_results) == 1, refund_results
    assert sum(x == ("http", 409) for x in refund_results) == 1, refund_results
    assert abs(refund_total - 60.0) < 0.001, refund_total

    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        settlement_results = list(pool.map(attempt_settlement, (1, 2)))
    assert all(x[0] == "ok" for x in settlement_results), settlement_results
    assert settlement_results[0][1]["settlement_id"] == settlement_results[1][1]["settlement_id"], settlement_results
    with main.conn() as c:
        settlement_count = int(c.execute("SELECT COUNT(*) n FROM settlement_runs WHERE order_id=?", (settle_oid,)).fetchone()["n"])
        ledger_count = int(c.execute("SELECT COUNT(*) n FROM finance_ledger_entries WHERE order_id=?", (settle_oid,)).fetchone()["n"])
    assert settlement_count == 1, settlement_count
    assert ledger_count == 4, ledger_count
    print("V381_SQLITE_CONCURRENCY_REGRESSION_PASS refund_total=60/100 settlement_rows=1 ledger_rows=4")
finally:
    main.current_user = original_current_user
    try:
        with main.conn() as c:
            c.execute("DELETE FROM finance_ledger_entries WHERE order_id IN (?,?)", (refund_oid, settle_oid))
            c.execute("DELETE FROM refunds WHERE order_id=?", (refund_oid,))
            c.execute("DELETE FROM payments WHERE order_id=?", (refund_oid,))
            c.execute("DELETE FROM settlement_runs WHERE order_id=?", (settle_oid,))
            c.execute("DELETE FROM orders WHERE id IN (?,?)", (refund_oid, settle_oid))
            c.execute("DELETE FROM customers WHERE id=?", (cid,))
            c.execute("DELETE FROM merchants WHERE id=?", (mid,))
            c.execute("DELETE FROM users WHERE id=?", (uid,))
            c.commit()
    finally:
        try:
            os.remove(DB)
        except OSError:
            pass
