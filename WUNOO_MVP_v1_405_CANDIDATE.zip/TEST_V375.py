from pathlib import Path

source = (Path(__file__).parent / "app" / "main.py").read_text(encoding="utf-8")
routes = [
    ("/api/v058/checkout/confirm", "\n@app.", "legacy V058"),
    ("/api/v283/checkout/confirm", "@app.get('/frontend_v029/checkout_v283.html')", "V283"),
    ("/api/v139/checkout/confirm", '@app.get("/api/v139/ops/finance-cutover-status")', "V139"),
]
for route_marker, end_marker, label in routes:
    start = source.index(route_marker)
    end = source.index(end_marker, start)
    route = source[start:end]
    assert "FOR UPDATE" in route, f"{label}: PostgreSQL quote row lock missing"
    assert "getattr(c" in route and "postgresql" in route, f"{label}: backend-gated lock missing"
    assert route.index("FOR UPDATE") < route.index("if q[") if "if q[" in route else True, f"{label}: lock must precede quote status checks"
print("V375_CHECKOUT_CONFIRM_ROW_LOCK_GUARD_PASS routes=3")
