import os,tempfile
DB=os.path.join(tempfile.gettempdir(),'wunoo_v342_atomic.db')
try: os.remove(DB)
except FileNotFoundError: pass
os.environ['WUNOO_DB_PATH']=DB
import app.main as m
m.init_db()
with m.core_db_connect() as c:
    names='migrate_v046 migrate_v052 migrate_v053 migrate_v061 migrate_v119 migrate_v120 migrate_v121 migrate_v122 migrate_v310 migrate_v311 migrate_v312 migrate_v313 migrate_v314 migrate_v315 migrate_v316 migrate_v318 migrate_v319 migrate_v321 migrate_v322 migrate_v323 migrate_v325 migrate_v326 migrate_v328 migrate_v329 migrate_v330 migrate_v331 migrate_v332 migrate_v333 migrate_v334 migrate_v335 migrate_v336 migrate_v337 migrate_v338 migrate_v339 migrate_v340 migrate_v341 migrate_v342'.split()
    for n in names: getattr(m,n)(c)
    c.commit()
r=m._v342_atomicity_chaos()
assert r['passed'],r
assert r['failed_transaction_rolled_back'],r
assert r['partial_evidence_rows']==0,r
assert not r['lease_left_active_after_rollback'],r
assert r['successful_atomic_transaction'],r
print('FAILED_TRANSACTION_ROLLED_BACK 1')
print('PARTIAL_EVIDENCE_ROWS 0')
print('LEASE_LEFT_ACTIVE_AFTER_ROLLBACK 0')
print('SUCCESSFUL_ATOMIC_TRANSACTION 1')
print('V342_OK')
