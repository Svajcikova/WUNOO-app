"""Regression: signed payment webhooks must strictly validate field types."""
import os, sys, json, hmac, hashlib, tempfile, uuid
from pathlib import Path
from fastapi.testclient import TestClient
ROOT=Path(__file__).resolve().parent
secret=b'test-secret-v392'
os.environ['WUNOO_PAYMENT_WEBHOOK_SECRET']=secret.decode()
os.environ['WUNOO_DB_PATH']=os.path.join(tempfile.gettempdir(),'wunoo_v392_'+uuid.uuid4().hex+'.db')
sys.path.insert(0,str(ROOT))
from app import main
PATHS=['/api/v059/payment/webhook','/api/v140/payment/webhook','/api/v141/payment/webhook']
BASE={'id':'evt-v392','type':'payment_failed','payment_intent_id':'pi-does-not-exist'}
CASES=[
    ({'id': [], 'type':'payment_failed','payment_intent_id':'pi'}, 'WEBHOOK_FIELD_INVALID'),
    ({'id':'evt','type': [],'payment_intent_id':'pi'}, 'WEBHOOK_FIELD_INVALID'),
    ({'id':'evt','type':'payment_failed','payment_intent_id':{}}, 'WEBHOOK_FIELD_INVALID'),
    ({'id':'evt','type':'payment_failed','payment_intent_id':'pi','currency':[]}, 'WEBHOOK_FIELD_INVALID'),
    ({'id':'evt','type':'payment_failed','payment_intent_id':'pi','amount':{}}, 'PAYMENT_AMOUNT_INVALID'),
    ({'id':'evt','type':'payment_failed','payment_intent_id':'pi','amount':True}, 'PAYMENT_AMOUNT_INVALID'),
    ({'id':'evt','type':'payment_failed','payment_intent_id':'pi','amount':'NaN'}, 'PAYMENT_AMOUNT_INVALID'),
    ({'id':'evt','type':'not-a-real-event','payment_intent_id':'pi'}, 'WEBHOOK_EVENT_TYPE_INVALID'),
]
def post(client,path,body):
    raw=json.dumps(body,separators=(',',':')).encode()
    sig='sha256='+hmac.new(secret,raw,hashlib.sha256).hexdigest()
    return client.post(path,content=raw,headers={'X-WUNOO-Signature':sig,'Content-Type':'application/json'})
with TestClient(main.app) as client:
    total=0
    for path in PATHS:
        for body,code in CASES:
            r=post(client,path,body)
            assert r.status_code==400,(path,body,r.status_code,r.text)
            detail=r.json().get('detail')
            assert isinstance(detail,dict) and detail.get('code')==code,(path,body,r.text)
            total+=1
    # Numeric string is intentionally still accepted by schema validation (then may 404 because PI absent).
    r=post(client,'/api/v059/payment/webhook',{**BASE,'amount':'12.50'})
    assert r.status_code==404,(r.status_code,r.text)
print(f'V392_WEBHOOK_FIELD_TYPE_GUARD_PASS paths=3 invalid_cases={total} numeric_string_compat=PASS')
