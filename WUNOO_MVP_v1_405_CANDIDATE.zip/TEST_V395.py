"""v1.395 regression: immutable event IDs on both legacy replay paths."""
import os, sys, tempfile, uuid
from pathlib import Path
from fastapi import HTTPException
ROOT=Path(__file__).resolve().parent
os.environ['WUNOO_DB_PATH']=os.path.join(tempfile.gettempdir(),'wunoo_v395_'+uuid.uuid4().hex+'.db')
sys.path.insert(0,str(ROOT))
from app import main
body={'id':'evt-v395','type':'payment_failed','payment_intent_id':'pi-v395'}
row={'payload_json':main.json.dumps(body,ensure_ascii=False),'event_type':'payment_failed','status':'processed'}
main._v049_validate_webhook_replay(row,body['id'],body['type'],body)
for changed, event_type in [({**body,'order_id':'other'},'payment_failed'),(body,'payment_succeeded')]:
    try:
        main._v049_validate_webhook_replay(row,body['id'],event_type,changed)
    except HTTPException as exc:
        assert exc.status_code==409 and exc.detail['code']=='WEBHOOK_EVENT_ID_PAYLOAD_MISMATCH',(exc.status_code,exc.detail)
    else:
        raise AssertionError('changed payload/event type was accepted')
# Corrupt stored JSON must fail closed rather than be treated as a duplicate.
try:
    main._v049_validate_webhook_replay({**row,'payload_json':'not-json'},body['id'],body['type'],body)
except HTTPException as exc:
    assert exc.status_code==409 and exc.detail['code']=='WEBHOOK_EVENT_ID_PAYLOAD_MISMATCH'
else:
    raise AssertionError('corrupt stored payload was accepted')
print('V395_LEGACY_WEBHOOK_RACE_REPLAY_GUARD_PASS identical=PASS changed_payload=409 changed_type=409 corrupt_stored_payload=409')
