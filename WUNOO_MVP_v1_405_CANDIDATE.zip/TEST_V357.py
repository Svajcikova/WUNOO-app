import os,tempfile
DB=os.path.join(tempfile.gettempdir(),'wunoo_v357_complete_scan.db')
try: os.remove(DB)
except FileNotFoundError: pass
os.environ['WUNOO_DB_PATH']=DB
import app.main as m
m.init_db()
with m.core_db_connect() as c:
    for name in 'migrate_v046 migrate_v052 migrate_v053 migrate_v061 migrate_v119 migrate_v120 migrate_v121 migrate_v122 migrate_v310 migrate_v311 migrate_v312 migrate_v313 migrate_v314 migrate_v315 migrate_v316 migrate_v318 migrate_v319 migrate_v321 migrate_v322 migrate_v323 migrate_v325 migrate_v326 migrate_v328 migrate_v329 migrate_v330 migrate_v331 migrate_v332 migrate_v333 migrate_v334 migrate_v335 migrate_v336 migrate_v337 migrate_v338 migrate_v339 migrate_v340 migrate_v341 migrate_v342 migrate_v343 migrate_v344 migrate_v345 migrate_v346 migrate_v347 migrate_v348 migrate_v349 migrate_v350 migrate_v351 migrate_v352 migrate_v353 migrate_v354 migrate_v355 migrate_v356 migrate_v357'.split(): getattr(m,name)(c)
    ts=m.datetime.now(m.timezone.utc).isoformat()
    c.execute("INSERT INTO merchants(id,name,created_at) VALUES(?,?,?)",('v357_merch','V357',ts))
    c.execute("INSERT INTO customers(id,name,email,created_at) VALUES(?,?,?,?)",('v357_cust','V357','v357@test',ts))
    c.execute("INSERT INTO couriers(id,name,status,created_at) VALUES(?,?,?,?)",('v357_courier','V357','online',ts))
    for i in range(501):
        oid=f'v357_o_{i:04d}'; jid=f'v357_j_{i:04d}'
        c.execute("INSERT INTO orders(id,customer_id,merchant_id,status,subtotal_czk,service_fee_czk,delivery_fee_czk,total_czk,address,created_at,updated_at,courier_id,assigned_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",(oid,'v357_cust','v357_merch','courier_assigned',100,0,0,100,'A',ts,ts,'v357_courier',ts))
        courier='wrong_courier' if i==500 else 'v357_courier'
        c.execute("INSERT INTO dispatch_jobs(id,order_id,merchant_id,courier_id,status,pickup_eta_minutes,delivery_eta_minutes,offered_at,created_at,updated_at,dispatch_generation) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(jid,oid,'v357_merch',courier,'accepted',1,1,ts,ts,ts,1))
    # 600 terminal rows must not participate in the active invariant scan.
    for i in range(600):
        oid=f'v357_t_{i:04d}'
        c.execute("INSERT INTO orders(id,customer_id,merchant_id,status,subtotal_czk,service_fee_czk,delivery_fee_czk,total_czk,address,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(oid,'v357_cust','v357_merch','delivered',100,0,0,100,'A',ts,ts))
    c.commit()
with m.core_db_connect() as c:
    r=m._v357_full_invariant_scan(c,record=False)
    assert not r['passed'],r
    assert any(v['code']=='ASSIGNMENT_STATE_MISMATCH' and v['row']['id']=='v357_o_0500' for v in r['violations']),r
    assert r['active_orders']==501,r
print('SCAN_BEYOND_500_FAIL_CLOSED 1')
with m.core_db_connect() as c:
    c.execute("UPDATE dispatch_jobs SET courier_id=? WHERE id=?",('v357_courier','v357_j_0500')); c.commit()
with m.core_db_connect() as c:
    r=m._v357_full_invariant_scan(c,record=False)
    assert r['passed'],r
print('FULL_ACTIVE_SCAN_PASS 1')
print('TERMINAL_HISTORY_EXCLUDED 1')
print('V357_OK')
