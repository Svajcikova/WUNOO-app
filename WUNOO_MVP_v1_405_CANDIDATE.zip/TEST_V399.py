"""v1.399 regression: payout replay must validate the complete payout set."""
import os, sys, tempfile, uuid
from pathlib import Path
from fastapi import HTTPException
ROOT = Path(__file__).resolve().parent
os.environ['WUNOO_DB_PATH'] = os.path.join(tempfile.gettempdir(), 'wunoo_v399_' + uuid.uuid4().hex + '.db')
sys.path.insert(0, str(ROOT))
from app import main

snap = {
    'order': {'id': 'ord-399', 'merchant_id': 'merchant-1', 'courier_id': 'courier-1'},
    'merchant_czk': 70.0, 'courier_czk': 20.0, 'platform_czk': 10.0,
    'settlement_id': 'set-399'
}
def row(kind, beneficiary, amount, status='completed', settlement='set-399'):
    return {'id': 'pay-' + kind, 'order_id': 'ord-399', 'beneficiary_type': kind,
            'beneficiary_id': beneficiary, 'amount_czk': amount, 'status': status,
            'settlement_id': settlement, 'created_at': 't', 'completed_at': 't'}
valid = [row('merchant', 'merchant-1', 70), row('courier', 'courier-1', 20), row('platform', None, 10)]
assert len(main._v120_validate_existing_payouts('ord-399', snap, 0, valid)) == 3

def reject(rows, legacy=0):
    try:
        main._v120_validate_existing_payouts('ord-399', snap, legacy, rows)
    except HTTPException as exc:
        assert exc.status_code == 409 and exc.detail['code'] == 'PAYOUT_LEDGER_INCONSISTENT', (exc.status_code, exc.detail)
    else:
        raise AssertionError('inconsistent payout set was accepted')

reject(valid[:1])
reject([row('merchant', 'merchant-1', 70), row('courier', 'courier-1', 20, status='pending'), row('platform', None, 10)])
reject([row('merchant', 'merchant-1', 69), *valid[1:]])
reject([row('merchant', 'other-merchant', 70), *valid[1:]])
reject([row('merchant', 'merchant-1', 70), row('courier', 'courier-1', 20), row('platform', None, 10, settlement='other-settlement')])
# When legacy courier credit already represents courier earnings, courier must not be paid again.
legacy_expected = [row('merchant', 'merchant-1', 70), row('platform', None, 10)]
assert len(main._v120_validate_existing_payouts('ord-399', snap, 20, legacy_expected)) == 2
reject(valid, legacy=20)
print('V399_PAYOUT_REPLAY_INTEGRITY_PASS valid_full_set=PASS partial=409 pending=409 amount=409 beneficiary=409 settlement_binding=409 legacy_double_pay=409')
