"""Regression: every payment webhook endpoint enforces a streamed body cap."""
import os, sys, json, hmac, hashlib, tempfile, uuid
from pathlib import Path
from fastapi.testclient import TestClient
ROOT=Path(__file__).resolve().parent
SECRET=b'test-secret-v393'
os.environ['WUNOO_PAYMENT_WEBHOOK_SECRET']=SECRET.decode()
os.environ['WUNOO_DB_PATH']=os.path.join(tempfile.gettempdir(),'wunoo_v393_'+uuid.uuid4().hex+'.db')
sys.path.insert(0,str(ROOT))
from app import main
PATHS=[
    '/api/v049/webhooks/test-provider',
    '/api/v051/payment-webhook',
    '/api/v059/payment/webhook',
    '/api/v140/payment/webhook',
    '/api/v141/payment/webhook',
]
MAX=main.V100_PAYMENT_WEBHOOK_MAX_BODY_BYTES
# Valid JSON and a correct HMAC, deliberately over the cap by a wide margin.
raw=json.dumps({'id':'evt-v393','type':'payment_failed','payment_intent_id':'pi-missing','padding':'x'*(MAX+1024)},separators=(',',':')).encode()
assert len(raw)>MAX
sig='sha256='+hmac.new(SECRET,raw,hashlib.sha256).hexdigest()
with TestClient(main.app) as client:
    for path in PATHS:
        response=client.post(path,content=raw,headers={'X-WUNOO-Signature':sig,'Content-Type':'application/json'})
        assert response.status_code==413,(path,response.status_code,response.text)
        detail=response.json().get('detail')
        assert isinstance(detail,dict) and detail.get('code')=='WEBHOOK_BODY_TOO_LARGE',(path,response.text)
# Small bodies still pass the reader and reach normal JSON/signature validation.
small=b'{"id":"evt-small","type":"payment_failed","payment_intent_id":"pi-missing"}'
small_sig='sha256='+hmac.new(SECRET,small,hashlib.sha256).hexdigest()
with TestClient(main.app) as client:
    response=client.post('/api/v059/payment/webhook',content=small,headers={'X-WUNOO-Signature':small_sig,'Content-Type':'application/json'})
    assert response.status_code==404,(response.status_code,response.text)
print(f'V393_WEBHOOK_BODY_LIMIT_PASS endpoints={len(PATHS)} max_bytes={MAX} oversize_rejected=PASS small_body_compat=PASS')
