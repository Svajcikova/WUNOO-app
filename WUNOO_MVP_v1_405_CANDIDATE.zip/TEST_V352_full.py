from app.main import _v352_chaos
r=_v352_chaos()
assert r['passed'] is True
assert r['seeds']==25
assert r['failures']==0
assert r['crash_cases']==25
assert r['takeovers_verified']==25
assert r['stale_owner_fencing_verified']==25
assert r['boot_recovered']==25
assert r['lease_clean']==25
print('V352_OK')
print('SEEDS',r['seeds'])
print('FAILURES',r['failures'])
print('TAKEOVERS_VERIFIED',r['takeovers_verified'])
print('STALE_OWNER_FENCING_VERIFIED',r['stale_owner_fencing_verified'])
print('BOOT_RECOVERED',r['boot_recovered'])
print('LEASE_CLEAN',r['lease_clean'])
