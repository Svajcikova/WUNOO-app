import os,tempfile
DB=os.path.join(tempfile.gettempdir(),'wunoo_v344_test.db')
try: os.remove(DB)
except FileNotFoundError: pass
os.environ['WUNOO_DB_PATH']=DB
import app.main as m
m.init_db()
with m.closing(m.conn()) as c:
    m._run_all_migrations(c)
    assert m._v341_table_exists(c,'ai_dispatch_recovery_crash_concurrency_v344')
r=m._v344_crash_concurrency_matrix()
assert r['passed'],r
assert len(r['results'])==4,r
assert all(x['sigkill_workers']==1 for x in r['results']),r
assert r['duplicate_recovery_mutations']==0,r
assert r['unresolved_provable_residues']==0,r
print('CONCURRENCY_ITERATIONS 4')
print('SIGKILL_SCENARIOS 4')
print('DUPLICATE_RECOVERY_MUTATIONS 0')
print('UNRESOLVED_PROVABLE_RESIDUES 0')
print('V344_OK')
