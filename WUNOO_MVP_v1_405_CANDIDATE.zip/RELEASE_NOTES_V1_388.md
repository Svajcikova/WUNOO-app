# WUNOO v1.388 Candidate — legacy v1.059 terminal payment-state guard

## Changes
- Added a terminal-state guard to `/api/v059/payment/webhook` after immutable event-ID replay checks and before any payment-intent mutation.
- A new event ID repeating the same terminal state is acknowledged as ignored, without rewriting the intent or attempting a second order transition.
- Late `payment_failed` / `payment_cancelled` events after `succeeded` are ignored.
- Contradictory terminal transitions (for example `failed` → `cancelled` or `cancelled` → `succeeded`) return HTTP 409 and preserve the stored terminal intent state.
- Optional amount and currency claims are validated before an event is ignored due to terminal state; non-finite or mismatched amounts return HTTP 409.
- Added `TEST_V388.py` covering late events, same-terminal replays with a new event ID, contradictory terminal transitions, amount mismatch against a terminal intent, and a valid success from a nonterminal state.

## Verification
- `python -m compileall -q app` — PASS.
- `TEST_V388.py` — PASS.
- Selected payment/refund/order regressions `TEST_V362.py`, `TEST_V372.py`, `TEST_V377_runtime.py`, and `TEST_V378.py` through `TEST_V388.py` — PASS when run individually.
- ZIP integrity — verified after archive creation.

## Limitations / status
- The v1.059 handler uses the legacy SQLite connection (`conn()`); this patch does not convert that legacy endpoint to PostgreSQL.
- No live PostgreSQL integration test is claimed.
- Candidate only; not production-approved and not pushed to GitHub.
