import ast
from pathlib import Path
p=Path('app/main.py'); t=ast.parse(p.read_text(encoding='utf-8'))
fn=next(n for n in t.body if isinstance(n,ast.FunctionDef) and n.name=='create_dispatch_offer')
body=ast.unparse(fn)
assert "require_role(u, 'admin', 'ops_agent')" in body
assert 'u["role"] == "courier"' not in body
assert 'u["courier_id"]' not in body
print('V364_DISPATCH_OFFER_AUTHZ_PASS', {'courier_denied_by_role_gate': True, 'control_plane_roles': ['admin','ops_agent']})
