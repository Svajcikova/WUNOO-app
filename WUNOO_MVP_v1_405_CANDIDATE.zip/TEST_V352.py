from app.main import _v352_chaos
r=_v352_chaos()
assert r['passed'] is True
assert r['seeds']==3
assert r['failures']==0
assert r['crash_cases']==3
assert r['takeovers_verified']==3
assert r['stale_owner_fencing_verified']==3
assert r['boot_recovered']==3
assert r['lease_clean']==3
print('V352_OK')
print('SEEDS',r['seeds'])
print('FAILURES',r['failures'])
print('TAKEOVERS_VERIFIED',r['takeovers_verified'])
print('STALE_OWNER_FENCING_VERIFIED',r['stale_owner_fencing_verified'])
print('BOOT_RECOVERED',r['boot_recovered'])
print('LEASE_CLEAN',r['lease_clean'])
