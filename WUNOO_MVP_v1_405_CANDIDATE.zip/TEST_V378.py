import os, sys, uuid, tempfile
from pathlib import Path
DB=os.path.join(tempfile.gettempdir(), "wunoo_v378_"+uuid.uuid4().hex+".db")
os.environ["WUNOO_DB_PATH"]=DB
sys.path.insert(0, os.path.dirname(__file__))
from app import main
from fastapi import HTTPException
main.init_db()
with main.conn() as c:
    main.migrate_v049(c)
    main.migrate_v064(c)
    main.migrate_v120(c)
uid="u_v378_"+uuid.uuid4().hex[:8]; cid="c_v378_"+uuid.uuid4().hex[:8]; mid="m_v378_"+uuid.uuid4().hex[:8]
order="o_v378_"+uuid.uuid4().hex[:8]; payment="p_v378_"+uuid.uuid4().hex[:8]; ts=main.now()
with main.conn() as c:
    c.execute("INSERT INTO users(id,email,name,role,active,created_at,password_hash) VALUES(?,?,?,?,?,?,?)",(uid,uid+"@x.test","V378 Admin","admin",1,ts,"x"))
    c.execute("INSERT INTO customers(id,name,email,created_at) VALUES(?,?,?,?)",(cid,"V378 Customer",uid+"@x.test",ts))
    c.execute("INSERT INTO merchants(id,name,created_at) VALUES(?,?,?)",(mid,"V378 Merchant",ts))
    c.execute("INSERT INTO orders(id,customer_id,merchant_id,status,subtotal_czk,service_fee_czk,delivery_fee_czk,total_czk,address,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(order,cid,mid,"delivered",100,0,0,100,"V378",ts,ts))
    c.execute("INSERT INTO payments(id,order_id,provider_payment_id,amount_czk,status,created_at) VALUES(?,?,?,?,?,?)",(payment,order,"provider_"+payment,100,"captured",ts))
    main.insert_refund(c,"prior_"+uuid.uuid4().hex[:8],order,payment,60,"cross_version","processed","provider_ref_"+uuid.uuid4().hex[:8])
    c.commit()
old=main.current_user
main.current_user=lambda authorization: {"id":uid,"role":"admin"}
try:
    try:
        main.v049_partial_refund(order,{"amount_czk":50},None)
        raise AssertionError("cross-version over-refund was accepted: 60 processed + 50 new > 100 captured")
    except HTTPException as e:
        assert e.status_code==409, (e.status_code,e.detail)
    with main.conn() as c:
        total=float(c.execute("SELECT COALESCE(SUM(amount_czk),0) n FROM refunds WHERE order_id=? AND status IN ('pending','processed','succeeded')",(order,)).fetchone()["n"])
        assert total==60.0, total
        remaining=float(c.execute("SELECT COALESCE(SUM(amount_czk),0) n FROM refunds WHERE order_id=? AND status IN ('processed','succeeded')",(order,)).fetchone()["n"])
        assert remaining==60.0, remaining
finally:
    main.current_user=old
    with main.conn() as c:
        c.execute("DELETE FROM finance_ledger_entries WHERE order_id=?",(order,))
        c.execute("DELETE FROM refunds WHERE order_id=?",(order,))
        c.execute("DELETE FROM payments WHERE order_id=?",(order,))
        c.execute("DELETE FROM orders WHERE id=?",(order,))
        c.execute("DELETE FROM customers WHERE id=?",(cid,))
        c.execute("DELETE FROM merchants WHERE id=?",(mid,))
        c.execute("DELETE FROM users WHERE id=?",(uid,))
        c.commit()
    try: os.remove(DB)
    except OSError: pass
source=Path(__file__).with_name("app").joinpath("main.py").read_text(encoding="utf-8")
route=source.split('@app.post("/api/v049/orders/{order_id}/partial-refund")',1)[1].split('@app.get("/api/v049/orders/{order_id}/reconciliation")',1)[0]
assert "status IN ('pending','processed','succeeded')" in route
print("V378_CROSS_VERSION_REFUND_CAP_PASS prior_processed=60 new_refund=50 rejected=409")
