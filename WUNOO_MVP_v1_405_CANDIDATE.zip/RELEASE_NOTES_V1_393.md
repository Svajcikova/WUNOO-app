# WUNOO v1.393 Candidate

## Change

Added bounded streaming reads for payment webhook request bodies. A shared reader enforces a hard **64 KiB** maximum across `/api/v049/webhooks/{provider}`, `/api/v051/payment-webhook`, `/api/v059/payment/webhook`, `/api/v140/payment/webhook`, and `/api/v141/payment/webhook`. It rejects oversized declared `Content-Length` values early and also counts streamed bytes, so requests without a trustworthy length header cannot bypass the cap. Oversized requests receive HTTP 413 (`WEBHOOK_BODY_TOO_LARGE`); malformed length values receive HTTP 400 (`WEBHOOK_CONTENT_LENGTH_INVALID`).

## Verification

- `python -m compileall -q app` — PASS
- `TEST_V393.py` — verifies oversized requests are rejected on all 5 webhook endpoints and a normal signed body reaches regular processing
- `TEST_V392.py` — strict webhook field validation regression
- `TEST_V391.py` — invalid JSON root regression
- `TEST_V390.py`, `TEST_V389.py` — legacy webhook amount/state regressions
- ZIP integrity check — performed on final candidate archive

## Limitations

Candidate verification is local and uses SQLite; PostgreSQL integration/concurrency was not run for this build. This is not production approval. No deployment or GitHub push was performed.
