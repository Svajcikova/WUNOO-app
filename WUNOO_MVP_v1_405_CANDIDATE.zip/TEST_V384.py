"""v1.384 regression: concurrent duplicate v1.059 payment webhook delivery is idempotent."""
import os, sys, json, hmac, hashlib, uuid, tempfile
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from fastapi.testclient import TestClient

ROOT = Path(__file__).resolve().parent
os.environ['WUNOO_PAYMENT_WEBHOOK_SECRET'] = 'test-secret-v384'
os.environ['WUNOO_DB_PATH'] = os.path.join(tempfile.gettempdir(), 'wunoo_v384_' + uuid.uuid4().hex + '.db')
sys.path.insert(0, str(ROOT))
from app import main
main.transition = lambda *args, **kwargs: None
main._v053_log = lambda *args, **kwargs: None

suffix=uuid.uuid4().hex[:10]
uid='u_v384_'+suffix; cid='c_v384_'+suffix; mid='m_v384_'+suffix
order_id='o_v384_'+suffix; intent_id='pi_v384_'+suffix; event_id='evt_v384_'+suffix
stamp=main.now()
with TestClient(main.app) as client:
    main.migrate_v049(main.conn())
    main.migrate_v059(main.conn())
    with main.conn() as c:
        c.execute("INSERT INTO users(id,email,name,role,active,created_at,password_hash) VALUES(?,?,?,?,?,?,?)",(uid,uid+'@x.test','V384','customer',1,stamp,'x'))
        c.execute("INSERT INTO customers(id,name,email,created_at) VALUES(?,?,?,?)",(cid,'V384 Customer',uid+'@x.test',stamp))
        c.execute("INSERT INTO merchants(id,name,created_at) VALUES(?,?,?)",(mid,'V384 Merchant',stamp))
        c.execute("INSERT INTO orders(id,customer_id,merchant_id,status,subtotal_czk,service_fee_czk,delivery_fee_czk,total_czk,address,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(order_id,cid,mid,'payment_pending',100,10,10,120,'V384',stamp,stamp))
        c.execute("INSERT INTO payment_intents(id,order_id,amount_czk,currency,status,provider,provider_intent_id,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",(intent_id,order_id,120,'CZK','requires_payment_method','test','prov_'+intent_id,stamp,stamp))
        c.commit()
    body={'id':event_id,'type':'payment_succeeded','payment_intent_id':intent_id,'amount_czk':120,'currency':'CZK'}
    raw=json.dumps(body,separators=(',',':')).encode()
    sig='sha256='+hmac.new(b'test-secret-v384',raw,hashlib.sha256).hexdigest()
    headers={'X-WUNOO-Signature':sig,'Content-Type':'application/json'}
    def send(_):
        r=client.post('/api/v059/payment/webhook',content=raw,headers=headers)
        return r.status_code, r.json()
    with ThreadPoolExecutor(max_workers=2) as pool:
        results=list(pool.map(send,[1,2]))
    assert all(status==200 for status,_ in results), results
    assert sum(1 for _,data in results if data.get('duplicate') is True)==1, results
    with main.conn() as c:
        events=c.execute('SELECT COUNT(*) n FROM payment_webhook_events WHERE provider_event_id=?',(event_id,)).fetchone()['n']
        pi=c.execute('SELECT status FROM payment_intents WHERE id=?',(intent_id,)).fetchone()['status']
    assert events==1, events
    assert pi=='succeeded', pi
    print('V384_CONCURRENT_PAYMENT_WEBHOOK_DEDUP_PASS responses='+json.dumps(results,sort_keys=True)+' event_rows=1 intent=succeeded')
