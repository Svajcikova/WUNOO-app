import ast
from pathlib import Path
p=Path('app/main.py')
t=ast.parse(p.read_text(encoding='utf-8'))
funcs={n.name:n for n in t.body if isinstance(n,ast.FunctionDef)}
body=ast.unparse(funcs['order_courier_candidates'])
assert "require_role(u, 'admin', 'merchant')" in body
assert "require_role(u, 'courier', 'admin', 'merchant')" not in body
body2=ast.unparse(funcs['orders'])
assert "WHERE o.courier_id=? ORDER BY o.created_at DESC" in body2
assert "OR (o.status='dispatch_pending')" not in body2
print('V365_COURIER_IDOR_GUARD_PASS', {'pending_order_enumeration_blocked':True,'candidate_enumeration_blocked':True,'assigned_orders_only':True})
