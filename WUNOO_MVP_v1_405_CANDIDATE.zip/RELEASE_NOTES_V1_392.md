# WUNOO v1.392 Candidate

## Change

Added shared strict field validation for the legacy payment webhook endpoints:

- `POST /api/v059/payment/webhook`
- `POST /api/v140/payment/webhook`
- `POST /api/v141/payment/webhook`

The validator rejects malformed identifier types, unsupported event types, malformed currency values, and non-finite/non-numeric amounts before database work. Numeric amount strings remain accepted for provider compatibility. Invalid inputs return HTTP 400 with a stable error code and do not create webhook-event records or mutate payment state.

## Verification performed

- `python -m compileall -q app` — PASS
- `TEST_V392.py` — PASS (24 invalid-field cases across 3 endpoints; numeric-string compatibility)
- `TEST_V391.py` — PASS (15 invalid JSON-root cases across 3 endpoints)
- `TEST_V390.py` — PASS
- `TEST_V389.py` — PASS
- `TEST_V388.py` — PASS
- `TEST_V372.py` — PASS
- `TEST_V377_runtime.py` — PASS
- `TEST_V378.py` through `TEST_V387.py` — each printed PASS; the overall batch later hit its external time limit after V387 output
- `TEST_V362.py` — PASS (golden order lifecycle, settlement and refund)
- ZIP integrity check — performed on the final candidate archive

## Limitations

These tests were run in the included local test setup (SQLite). A real PostgreSQL concurrency/integration run was not performed. This is a candidate build, not production approval. No deployment or GitHub push was performed.
