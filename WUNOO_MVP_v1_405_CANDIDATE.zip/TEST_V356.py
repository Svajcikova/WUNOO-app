import os, tempfile, sys, json
DB=os.path.join(tempfile.gettempdir(),'wunoo_v356_test.db')
try: os.remove(DB)
except FileNotFoundError: pass
os.environ['WUNOO_DB_PATH']=DB
sys.path.insert(0, os.path.dirname(__file__))
from app.main import *
import app.main as m
m.init_db()
with m.closing(m.conn()) as c:
    m._run_all_migrations(c)
    m.migrate_v356(c)
    # Seed a previously successful boot readiness proof for the lifecycle pre-gate.
    m._v336_boot_record(c,'seed356','READY',True,{'seed':True})
    c.commit()
# Seed durable healthy v1.354 evidence; the lifecycle under test remains real.
with m.core_db_connect() as c:
    c.execute("INSERT INTO ai_dispatch_recovery_observability_v354(id,run_id,cycle,active_leases,pending_journal,unresolved_recovery,active_locks,max_fencing_token,audit_rows,residue_free,monotonic_token,leak_detected,passed,detail_json,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)", ('seedobs356','seedobs356',1,0,0,0,0,1,1,1,1,0,1,'{}',m.datetime.now(m.timezone.utc).isoformat()))
    c.commit()
# Prove the current lease is not counted as a foreign active lease.
with m.core_db_connect() as c:
    m._v337_recovery_lock(c)
    owner='owner356_probe'
    token=m._v338_acquire_lease(c,owner)
    snap=m._v356_snapshot(c,owner_id=owner)
    assert snap['foreign_active_leases']==0, snap
    m._v338_release_lease(c,owner,token)
    c.rollback()
# Real lifecycle success.
r=m._v356_recovery_lifecycle()
assert r['passed'] is True, r
assert r['committed'] is True, r
assert r['pre_gate']['decision']=='HEALTHY', r
assert r['post_gate']['decision']=='HEALTHY', r
# Force the pre-gate to BLOCKED and prove no evidence from that blocked transaction commits.
with m.core_db_connect() as c:
    before=int(c.execute("SELECT COUNT(*) n FROM ai_dispatch_recovery_health_gate_v356").fetchone()['n'])
    c.execute("DELETE FROM ai_dispatch_recovery_observability_v354")
    c.commit()
blocked=m._v356_recovery_lifecycle()
assert blocked['blocked'] is True and blocked['committed'] is False, blocked
with m.core_db_connect() as c:
    after=int(c.execute("SELECT COUNT(*) n FROM ai_dispatch_recovery_health_gate_v356").fetchone()['n'])
assert after==before, (before,after)
print('V356_OK')
print('CURRENT_LEASE_EXCLUDED',True)
print('PRE_GATE_HEALTHY',r['pre_gate']['decision'])
print('POST_GATE_HEALTHY',r['post_gate']['decision'])
print('SUCCESS_COMMITTED',r['committed'])
print('BLOCKED_COMMITTED',blocked['committed'])
print('BLOCKED_EVIDENCE_ROLLED_BACK',after==before)
