"""Regression: strict HMAC grammar, JSON-root validation and immutable legacy event IDs."""
import os, sys, json, hmac, hashlib, tempfile, uuid
from pathlib import Path
from fastapi.testclient import TestClient
ROOT=Path(__file__).resolve().parent
SECRET=b'test-secret-v394'
os.environ['WUNOO_PAYMENT_WEBHOOK_SECRET']=SECRET.decode()
os.environ['WUNOO_DB_PATH']=os.path.join(tempfile.gettempdir(),'wunoo_v394_'+uuid.uuid4().hex+'.db')
sys.path.insert(0,str(ROOT))
from app import main
PATHS=['/api/v049/webhooks/test-provider','/api/v051/payment-webhook','/api/v059/payment/webhook','/api/v140/payment/webhook','/api/v141/payment/webhook']
def signed(raw):
    return 'sha256='+hmac.new(SECRET,raw,hashlib.sha256).hexdigest()
with TestClient(main.app) as client:
    # Invalid signature encodings must fail authentication consistently.
    for sig in ['sha256=abc','sha256='+'g'*64,'sha256='+'a'*63,'sha256='+'a'*65,'md5='+'a'*32]:
        r=client.post('/api/v059/payment/webhook',content=b'{}',headers={'X-WUNOO-Signature':sig,'Content-Type':'application/json'})
        assert r.status_code==401,(sig,r.status_code,r.text)
    # Legacy routes must reject validly signed non-object JSON instead of 500s.
    for path in PATHS[:2]:
        for raw in [b'null',b'[]',b'"text"',b'123',b'true']:
            r=client.post(path,content=raw,headers={'X-WUNOO-Signature':signed(raw),'Content-Type':'application/json'})
            assert r.status_code==400,(path,raw,r.status_code,r.text)
            assert r.json().get('detail',{}).get('code')=='WEBHOOK_BODY_INVALID',(path,raw,r.text)
    # Seed an existing legacy event then try to reuse its ID with changed payload.
    event_id='evt-v394-replay'
    original={'id':event_id,'type':'payment_failed','payment_intent_id':'pi-1'}
    with main.conn() as c:
        cols=[r['name'] for r in c.execute('PRAGMA table_info(payment_webhook_events)').fetchall()]
        values={'id':'wh_v394_seed','provider_event_id':event_id,'event_type':'payment_failed','payload_json':json.dumps(original,separators=(',',':')),'status':'processed','processed_at':main.now(),'created_at':main.now(),'payment_intent_id':'pi-1'}
        selected=[k for k in values if k in cols]
        c.execute('INSERT INTO payment_webhook_events ('+','.join(selected)+') VALUES ('+','.join('?' for _ in selected)+')',[values[k] for k in selected])
        c.commit()
    changed={**original,'order_id':'different-order'}
    raw=json.dumps(changed,separators=(',',':')).encode()
    r=client.post('/api/v049/webhooks/test-provider',content=raw,headers={'X-WUNOO-Signature':signed(raw),'Content-Type':'application/json'})
    assert r.status_code==409,(r.status_code,r.text)
    assert r.json().get('detail',{}).get('code')=='WEBHOOK_EVENT_ID_PAYLOAD_MISMATCH',r.text
print(f'V394_WEBHOOK_REPLAY_AND_SIGNATURE_PASS signature_cases=5 legacy_root_cases=10 replay_mismatch=PASS')
