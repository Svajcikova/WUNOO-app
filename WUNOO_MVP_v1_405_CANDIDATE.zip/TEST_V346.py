import os,tempfile
DB=os.path.join(tempfile.gettempdir(),'wunoo_v346_test.db')
try: os.remove(DB)
except FileNotFoundError: pass
os.environ['WUNOO_DB_PATH']=DB
import app.main as m
m.init_db()
with m.closing(m.conn()) as c:
    m._run_all_migrations(c)
    assert m._v341_table_exists(c,'ai_dispatch_recovery_model_checks_v346')
r=m._v346_state_model_check()
assert r['passed'],r
assert r['invalid_transition_accepts']==0,r
assert r['zero_invalid_commits']==1,r
assert len(r['fault_cases'])==10,r
assert sum(1 for x in r['fault_cases'] if x['committed'])==1,r
print('MODEL_STATES 10')
print('FAULT_CASES 10')
print('INVALID_TRANSITION_ACCEPTS 0')
print('INVALID_COMMITS 0')
print('VALID_COMMIT_PATHS 1')
print('V346_OK')
