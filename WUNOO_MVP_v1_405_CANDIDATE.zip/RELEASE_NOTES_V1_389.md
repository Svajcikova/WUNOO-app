# WUNOO v1.389 Candidate — malformed amount guard for v1.141 payment webhook

## Change
- Hardened `/api/v141/payment/webhook` provider amount parsing.
- Malformed numeric strings, booleans, and non-finite values (`NaN`, `Infinity`) now return HTTP 400 with `PAYMENT_AMOUNT_INVALID` instead of leaking an unhandled conversion error or reaching comparison logic.
- The event is not claimed and the payment intent is not mutated for invalid amount input.
- Valid but mismatched finite amounts continue to return HTTP 409 with `PAYMENT_AMOUNT_MISMATCH`.

## Verification
- `python -m compileall -q app` — PASS.
- `TEST_V389.py` — PASS: malformed string, boolean, positive infinity, and NaN rejected with 400; no event rows or payment state mutation; existing replay and terminal-state guards still pass.
- Individually passed regressions: `TEST_V388.py`, `TEST_V387.py`, `TEST_V386.py`, `TEST_V385.py`, `TEST_V384.py`, `TEST_V383.py`, `TEST_V382.py`, `TEST_V381.py`, `TEST_V380.py`, `TEST_V379.py`, `TEST_V378.py`, `TEST_V377_runtime.py`, `TEST_V372.py`, `TEST_V362.py`.

## Limitations / status
- These tests use the project's SQLite test setup; no live PostgreSQL integration test was run.
- Candidate only; not production-approved and not pushed to GitHub.
