from app.main import _v350_crash_conformance
r=_v350_crash_conformance()
assert r['passed'] is True
assert r['phases']==7
assert r['failures']==0
assert r['rollback_verified'] is True
assert r['boot_recovered'] is True
assert r['state_mismatches']==0
print('V350_OK')
print('PHASES',r['phases'])
print('FAILURES',r['failures'])
print('ROLLBACK_VERIFIED',r['rollback_verified'])
print('BOOT_RECOVERED',r['boot_recovered'])
print('STATE_MISMATCHES',r['state_mismatches'])
