"""v1.383 regression: PostgreSQL v1.18 refund command locks before idempotency read."""
import os, sys, tempfile, uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parent
source = (ROOT / "app" / "main.py").read_text(encoding="utf-8")
route = source.split('@app.post("/api/v118/orders/{order_id}/command")', 1)[1].split('@app.get("/api/v118/orders/{order_id}/integrity")', 1)[0]
lock_pos = route.find('if action == "refund" and getattr(c, "backend", "sqlite") == "postgresql":')
cache_pos = route.find('_v118_cached_command(c,scope,idempotency_key,payload)')
assert lock_pos >= 0 and cache_pos >= 0 and lock_pos < cache_pos, "PostgreSQL refund lock must precede idempotency cache read"

DB = os.path.join(tempfile.gettempdir(), "wunoo_v383_" + uuid.uuid4().hex + ".db")
os.environ["WUNOO_DB_PATH"] = DB
sys.path.insert(0, str(ROOT))
from app import main
main.init_db()
with main.core_db_connect() as c:
    main.migrate_v118(c)
    c.commit()

# Verify that the command log retains the original response for an exact replay
# and rejects reuse of the same key with a different payload.
scope = "v383:test:order"
key = "v383-same-key"
payload = {"order_id": "order-v383", "action": "refund", "amount_czk": 10.0}
try:
    with main.core_db_connect() as c:
        c.execute("BEGIN IMMEDIATE")
        assert main._v118_cached_command(c, scope, key, payload) is None
        result = {"refund_id": "refund-v383", "amount_czk": 10.0, "status": "processed"}
        main._v118_store_command(c, scope, key, payload, "refund", result)
        c.commit()
    with main.core_db_connect() as c:
        replay = main._v118_cached_command(c, scope, key, payload)
        assert replay == result, (replay, result)
        try:
            main._v118_cached_command(c, scope, key, payload | {"amount_czk": 11.0})
        except main.HTTPException as exc:
            assert exc.status_code == 409, exc.status_code
        else:
            raise AssertionError("reusing key with changed payload must be rejected")
    print("V383_V118_REFUND_IDEMPOTENCY_LOCK_ORDER_PASS source_lock_before_cache=True replay_identical=True changed_payload=409")
finally:
    try:
        with main.core_db_connect() as c:
            c.execute("DELETE FROM v118_command_log WHERE scope=?", (scope,))
            c.commit()
    except Exception:
        pass
    try:
        os.remove(DB)
    except OSError:
        pass
