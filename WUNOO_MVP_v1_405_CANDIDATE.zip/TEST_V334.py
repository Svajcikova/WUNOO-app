import os,tempfile,threading
DB=os.path.join(tempfile.gettempdir(),'wunoo_v334_recovery.db')
os.environ['WUNOO_DB_PATH']=DB
try: os.remove(DB)
except FileNotFoundError: pass
import app.main as m
m.init_db()
with m.core_db_connect() as c:
    for name in 'migrate_v046 migrate_v052 migrate_v053 migrate_v061 migrate_v119 migrate_v120 migrate_v121 migrate_v122 migrate_v310 migrate_v311 migrate_v312 migrate_v313 migrate_v314 migrate_v315 migrate_v316 migrate_v318 migrate_v319 migrate_v321 migrate_v322 migrate_v323 migrate_v325 migrate_v326 migrate_v328 migrate_v329 migrate_v330 migrate_v331 migrate_v332 migrate_v333 migrate_v334'.split(): getattr(m,name)(c)
    ts='2026-01-01T00:00:00'
    c.execute("INSERT INTO merchants(id,name,created_at) VALUES(?,?,?)",('m334','M334',ts))
    c.execute("INSERT INTO customers(id,name,email,created_at) VALUES(?,?,?,?)",('cust334','C334','c334@example.test',ts))
    for cid in ('c334a','c334b','c334c'):
        c.execute("INSERT INTO couriers(id,name,status,created_at) VALUES(?,?,?,?)",(cid,cid,'online',ts))
    c.execute("INSERT INTO orders(id,customer_id,merchant_id,status,subtotal_czk,service_fee_czk,delivery_fee_czk,total_czk,address,created_at,updated_at,courier_id,assigned_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",('o334','cust334','m334','courier_assigned',100,0,0,100,'A',ts,ts,'c334a',ts))
    c.execute("INSERT INTO dispatch_jobs(id,order_id,merchant_id,courier_id,status,pickup_eta_minutes,delivery_eta_minutes,offered_at,accepted_at,created_at,updated_at,dispatch_generation) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",('j334','o334','m334','c334a','accepted',5,25,ts,ts,ts,ts,1))
    c.commit()
actor={'id':'ops334','role':'ops_agent'}
# Clean successful command.
with m.core_db_connect() as c:
    r=m._v334_command(c,'key334','o334',actor,'operator_reassign',{'courier_id':'c334b','reason':'recovery-safe'},'1'); c.commit()
assert r['replayed'] is False and r['postcondition']['passed'] is True
# Recovery classifies completed journal as healthy and records audit.
with m.core_db_connect() as c:
    rec=m._v334_reconcile_order(c,'o334'); c.commit()
assert rec['passed'] and any(x['classification']=='HEALTHY_COMPLETED' for x in rec['results'])
# Exact replay remains non-mutating after recovery audit.
with m.core_db_connect() as c:
    r2=m._v334_command(c,'key334','o334',actor,'operator_reassign',{'courier_id':'c334b','reason':'recovery-safe'},'1'); c.commit()
assert r2['replayed'] is True
# Create a durable orphaned pending journal to emulate a legacy/crash residue.
with m.core_db_connect() as c:
    c.execute("INSERT INTO ai_dispatch_command_journal_v312(id,request_key,order_id,actor_id,command_type,status,response_json,evidence_sha256,created_at,completed_at,request_payload_sha256) VALUES(?,?,?,?,?,?,?,?,?,?,?)",('orphan334','orphan334','o334','ops334','operator_reassign','pending','{}','orphan','2026-01-01T01:00:00',None,m._v331_payload_hash({'courier_id':'c334c','reason':'orphan'})))
    c.commit()
# New mutation is fail-closed while orphan is unresolved.
try:
    with m.core_db_connect() as c:
        m._v334_command(c,'blocked334','o334',actor,'operator_reassign',{'courier_id':'c334c','reason':'blocked'},'2'); c.commit()
    raise AssertionError('orphan did not block')
except Exception as e:
    assert getattr(e,'status_code',None)==503, e
with m.core_db_connect() as c:
    state=c.execute("SELECT courier_id,dispatch_generation FROM dispatch_jobs WHERE id='j334'").fetchone()
assert state['courier_id']=='c334b' and int(state['dispatch_generation'])==2
# Unknown journal state is also fail-closed.
with m.core_db_connect() as c:
    c.execute("UPDATE ai_dispatch_command_journal_v312 SET status='weird' WHERE request_key='orphan334'")
    c.commit()
with m.core_db_connect() as c:
    rec=m._v334_reconcile_order(c,'o334'); c.commit()
assert not rec['passed'] and any(x['classification']=='INCONSISTENT' for x in rec['results'])
print('V334_OK')
print('HEALTHY_COMPLETED_RECONCILED',1)
print('EXACT_REPLAY_NON_MUTATING',1)
print('ORPHANED_PENDING_BLOCKED',1)
print('UNKNOWN_STATE_FAIL_CLOSED',1)
print('UNRESOLVED_MUTATIONS',0)
