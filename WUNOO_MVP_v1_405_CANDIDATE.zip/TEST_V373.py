import math, sys
from fastapi.testclient import TestClient
from app.main import app

c=TestClient(app)
# This test is source-level because auth fixture setup differs across local DBs.
s=open('app/main.py',encoding='utf-8').read()
assert 'if not math.isfinite(price) or price<0 or price>100000: raise HTTPException(400,"Neplatná cena")' in s
assert 'if not math.isfinite(changes["price_czk"]) or changes["price_czk"]<0: raise HTTPException(400,"Neplatná cena")' in s
assert 'if not math.isfinite(price) or price<0: raise HTTPException(400,"Neplatná cena")' in s
for x in (float("nan"), float("inf")):

    assert not math.isfinite(x)
print('V373_LEGACY_MENU_FINITE_PRICE_GUARD_PASS')
