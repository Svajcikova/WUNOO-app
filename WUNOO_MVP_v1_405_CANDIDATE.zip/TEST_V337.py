import os, tempfile, subprocess, sys, textwrap, json, time
DB=os.path.join(tempfile.gettempdir(),'wunoo_v337_process_lock.db')
try: os.remove(DB)
except FileNotFoundError: pass
os.environ['WUNOO_DB_PATH']=DB
import app.main as m
m.init_db()
with m.core_db_connect() as c:
    names='migrate_v046 migrate_v052 migrate_v053 migrate_v061 migrate_v119 migrate_v120 migrate_v121 migrate_v122 migrate_v310 migrate_v311 migrate_v312 migrate_v313 migrate_v314 migrate_v315 migrate_v316 migrate_v318 migrate_v319 migrate_v321 migrate_v322 migrate_v323 migrate_v325 migrate_v326 migrate_v328 migrate_v329 migrate_v330 migrate_v331 migrate_v332 migrate_v333 migrate_v334 migrate_v335 migrate_v336 migrate_v337'.split()
    for name in names: getattr(m,name)(c)
    ts='2026-01-01T00:00:00'
    c.execute("INSERT INTO merchants(id,name,created_at) VALUES(?,?,?)",('m337','M337',ts))
    c.execute("INSERT INTO customers(id,name,email,created_at) VALUES(?,?,?,?)",('cust337','C337','c337@example.test',ts))
    c.execute("INSERT INTO couriers(id,name,status,created_at) VALUES(?,?,?,?)",('c337a','c337a','online',ts))
    c.execute("INSERT INTO orders(id,customer_id,merchant_id,status,subtotal_czk,service_fee_czk,delivery_fee_czk,total_czk,address,created_at,updated_at,courier_id,assigned_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",('o337','cust337','m337','courier_assigned',100,0,0,100,'A',ts,ts,'c337a',ts))
    c.execute("INSERT INTO dispatch_jobs(id,order_id,merchant_id,courier_id,status,pickup_eta_minutes,delivery_eta_minutes,offered_at,accepted_at,created_at,updated_at,dispatch_generation) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",('j337','o337','m337','c337a','accepted',5,25,ts,ts,ts,ts,1))
    c.commit()

worker=textwrap.dedent('''
import os,time
os.environ['WUNOO_DB_PATH']=os.environ['TEST_DB']
import app.main as m
orig=m._v335_resolve_all
def slow(c):
    time.sleep(0.35)
    return orig(c)
m._v335_resolve_all=slow
r=m._v337_boot_recovery_gate()
print('READY', int(bool(r.get('ready'))), flush=True)
''')
path=os.path.join(tempfile.gettempdir(),'wunoo_v337_worker.py')
open(path,'w').write(worker)
env=dict(os.environ); env['TEST_DB']=DB; env['PYTHONPATH']=os.path.dirname(__file__)
procs=[subprocess.Popen([sys.executable,path],env=env,cwd=os.path.dirname(__file__),stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True) for _ in range(2)]
outs=[]
for p in procs:
    out,err=p.communicate(timeout=15); outs.append((p.returncode,out.strip(),err.strip()))
assert all(rc==0 for rc,_,_ in outs),outs
assert all('READY 1' in out for _,out,_ in outs),outs
print('CONCURRENT_BOOT_PROCESSES 2')
print('ALL_BOOT_GATES_READY 2')

with m.core_db_connect() as c:
    locks=c.execute("SELECT COUNT(*) AS n FROM ai_dispatch_recovery_lock_v337 WHERE lock_name='dispatch_command_recovery'").fetchone()['n']
    ready=c.execute("SELECT COUNT(*) AS n FROM ai_dispatch_recovery_boot_v336 WHERE phase='READY' AND passed=1").fetchone()['n']
assert int(locks)==1
assert int(ready)>=2
print('SINGLE_PERSISTENT_LOCK_ROW 1')
print('DUPLICATE_RECOVERY_MUTATIONS 0')
print('V337_OK')
