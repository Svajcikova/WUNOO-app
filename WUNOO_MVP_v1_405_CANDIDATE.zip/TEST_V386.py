"""v1.386 regression: v1.140 webhook event binding and immutable terminal states."""
import os, sys, json, hmac, hashlib, uuid, tempfile
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from fastapi.testclient import TestClient
ROOT=Path(__file__).resolve().parent
os.environ['WUNOO_PAYMENT_WEBHOOK_SECRET']='test-secret-v386'
os.environ['WUNOO_DB_PATH']=os.path.join(tempfile.gettempdir(),'wunoo_v386_'+uuid.uuid4().hex+'.db')
sys.path.insert(0,str(ROOT))
from app import main
main.transition=lambda *args,**kwargs: None
main.emit=lambda *args,**kwargs: None
suffix=uuid.uuid4().hex[:10]; uid='u_v386_'+suffix; cid='c_v386_'+suffix; mid='m_v386_'+suffix
order='o_v386_'+suffix; intent='pi_v386_'+suffix; event='evt_v386_'+suffix; stamp=main.now()
def send(client,body):
    raw=json.dumps(body,separators=(',',':')).encode()
    sig='sha256='+hmac.new(b'test-secret-v386',raw,hashlib.sha256).hexdigest()
    return client.post('/api/v140/payment/webhook',content=raw,headers={'X-WUNOO-Signature':sig,'Content-Type':'application/json'})
with TestClient(main.app) as client:
    with main.conn() as c:
        main.migrate_v049(c); main.migrate_v059(c); main.migrate_v140(c)
        c.execute("INSERT INTO users(id,email,name,role,active,created_at,password_hash) VALUES(?,?,?,?,?,?,?)",(uid,uid+'@x.test','V386','customer',1,stamp,'x'))
        c.execute("INSERT INTO customers(id,name,email,created_at) VALUES(?,?,?,?)",(cid,'V386 Customer',uid+'@x.test',stamp))
        c.execute("INSERT INTO merchants(id,name,created_at) VALUES(?,?,?)",(mid,'V386 Merchant',stamp))
        c.execute("INSERT INTO orders(id,customer_id,merchant_id,status,subtotal_czk,service_fee_czk,delivery_fee_czk,total_czk,address,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(order,cid,mid,'payment_pending',100,10,10,120,'V386',stamp,stamp))
        c.execute("INSERT INTO payment_intents(id,order_id,amount_czk,currency,status,provider,provider_intent_id,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",(intent,order,120,'CZK','requires_payment_method','test','prov_'+intent,stamp,stamp)); c.commit()
    original={'id':event,'type':'payment_succeeded','payment_intent_id':intent,'amount_czk':120,'currency':'CZK'}
    with ThreadPoolExecutor(max_workers=2) as pool:
        results=list(pool.map(lambda _: send(client,original),range(2)))
    assert all(r.status_code==200 for r in results), [(r.status_code,r.text) for r in results]
    assert sum(bool(r.json().get('duplicate')) for r in results)==1, [r.json() for r in results]
    replay=send(client,original); assert replay.status_code==200 and replay.json().get('duplicate') is True,(replay.status_code,replay.text)
    changed={**original,'amount_czk':119}
    mismatch=send(client,changed); assert mismatch.status_code==409 and mismatch.json().get('detail',{}).get('code')=='WEBHOOK_EVENT_ID_PAYLOAD_MISMATCH',(mismatch.status_code,mismatch.text)
    late=send(client,{'id':'evt_late_'+suffix,'type':'payment_failed','payment_intent_id':intent,'amount_czk':120,'currency':'CZK'})
    assert late.status_code==200 and late.json().get('ignored') is True,(late.status_code,late.text)
    with main.conn() as c:
        rows=c.execute('SELECT COUNT(*) n FROM payment_webhook_events WHERE payment_intent_id=?',(intent,)).fetchone()['n']
        pi=c.execute('SELECT status FROM payment_intents WHERE id=?',(intent,)).fetchone()['status']
    assert rows==2 and pi=='succeeded',(rows,pi)
    print('V386_V140_WEBHOOK_REPLAY_TERMINAL_GUARD_PASS concurrent_duplicates=1 event_rows=2 intent=succeeded changed_payload=409 late_failure=ignored')
