# WUNOO v1.394 Candidate

## Change

Continued the payment-webhook security audit with three targeted hardening changes:

1. **Strict HMAC-SHA256 signature grammar** — signatures must use the `sha256=` prefix and contain exactly 64 hexadecimal characters before constant-time digest comparison. Uppercase hex remains compatible.
2. **Immutable legacy event IDs** — `/api/v049/webhooks/{provider}` no longer silently acknowledges a reused provider event ID when its payload or event type differs from the originally stored event. It returns HTTP 409 with `WEBHOOK_EVENT_ID_PAYLOAD_MISMATCH`.
3. **JSON root validation for legacy endpoints** — `/api/v049/webhooks/{provider}` and `/api/v051/payment-webhook` return HTTP 400 (`WEBHOOK_BODY_INVALID`) for valid JSON whose root is not an object, rather than risking an attribute/type error and HTTP 500.

## Verification

- `python -m compileall -q app` — PASS
- `TEST_V394.py` — PASS: 5 malformed signature cases; 10 non-object JSON root cases; changed-payload replay rejected with HTTP 409
- `TEST_V393.py` — PASS: streamed 64 KiB body cap on all 5 webhook endpoints
- `TEST_V392.py` — PASS: 24 invalid webhook field cases
- `TEST_V391.py` — PASS: JSON-root validation regression
- `TEST_V390.py` — PASS: legacy finite-amount regression
- `TEST_V389.py` — PASS: v141 amount and terminal-state regression
- `TEST_V388.py` — PASS: v059 terminal-state regression
- `TEST_V362.py` — PASS: golden order lifecycle regression
- Final ZIP integrity check — PASS

## Limitations

Tests were run locally against the SQLite test setup. PostgreSQL integration/concurrency, external payment-provider certification, and production deployment checks were not run. This is a candidate build, not production approval. No GitHub push or deployment was performed.
