"""v1.388 regression: immutable terminal states on legacy v1.059 webhook."""
import os, sys, json, hmac, hashlib, tempfile, uuid
from pathlib import Path
from fastapi.testclient import TestClient
ROOT=Path(__file__).resolve().parent
os.environ['WUNOO_PAYMENT_WEBHOOK_SECRET']='test-secret-v388'
os.environ['WUNOO_DB_PATH']=os.path.join(tempfile.gettempdir(),'wunoo_v388_'+uuid.uuid4().hex+'.db')
sys.path.insert(0,str(ROOT))
from app import main
main.transition=lambda *args,**kwargs: None
main._v053_log=lambda *args,**kwargs: None
suffix=uuid.uuid4().hex[:10]; stamp=main.now()
def send(client, body):
    raw=json.dumps(body,separators=(',',':')).encode()
    sig='sha256='+hmac.new(b'test-secret-v388',raw,hashlib.sha256).hexdigest()
    return client.post('/api/v059/payment/webhook',content=raw,headers={'X-WUNOO-Signature':sig,'Content-Type':'application/json'})
with TestClient(main.app) as client:
    with main.conn() as c:
        main.migrate_v049(c); main.migrate_v059(c)
        cid='c_v388_'+suffix; mid='m_v388_'+suffix
        c.execute("INSERT INTO customers(id,name,email,created_at) VALUES(?,?,?,?)",(cid,'V388 Customer',cid+'@x.test',stamp))
        c.execute("INSERT INTO merchants(id,name,created_at) VALUES(?,?,?)",(mid,'V388 Merchant',stamp))
        cases=[('succeeded','merchant_pending'),('failed','payment_failed'),('cancelled','payment_cancelled'),('pending','payment_pending')]
        for state, order_state in cases:
            oid='o_v388_'+state+'_'+suffix; pid='pi_v388_'+state+'_'+suffix
            c.execute("INSERT INTO orders(id,customer_id,merchant_id,status,subtotal_czk,service_fee_czk,delivery_fee_czk,total_czk,address,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(oid,cid,mid,order_state,100,10,10,120,'V388',stamp,stamp))
            c.execute("INSERT INTO payment_intents(id,order_id,amount_czk,currency,status,provider,provider_intent_id,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",(pid,oid,120,'CZK',state,'test','prov_'+pid,stamp,stamp))
        c.commit()
    # Terminal status does not bypass amount/currency validation.
    r=send(client,{'id':'evt_v388_bad_terminal_amount_'+suffix,'type':'payment_succeeded','payment_intent_id':'pi_v388_succeeded_'+suffix,'amount_czk':1,'currency':'CZK'})
    assert r.status_code==409 and r.json().get('detail',{}).get('code')=='PAYMENT_AMOUNT_MISMATCH', (r.status_code,r.text)
    # A late failed event must not rewrite a successful intent.
    r=send(client,{'id':'evt_v388_latefail_'+suffix,'type':'payment_failed','payment_intent_id':'pi_v388_succeeded_'+suffix,'amount_czk':120,'currency':'CZK'})
    assert r.status_code==200 and r.json().get('ignored') is True, (r.status_code,r.text)
    # A new event ID with the same terminal status is idempotently ignored.
    r=send(client,{'id':'evt_v388_samefail_'+suffix,'type':'payment_failed','payment_intent_id':'pi_v388_failed_'+suffix,'amount_czk':120,'currency':'CZK'})
    assert r.status_code==200 and r.json().get('ignored') is True, (r.status_code,r.text)
    # Contradictory terminal transitions are explicit 409 conflicts.
    for event_type, pid in [('payment_cancelled','pi_v388_failed_'+suffix),('payment_succeeded','pi_v388_cancelled_'+suffix)]:
        r=send(client,{'id':'evt_v388_conflict_'+event_type+'_'+suffix,'type':event_type,'payment_intent_id':pid,'amount_czk':120,'currency':'CZK'})
        assert r.status_code==409 and r.json().get('detail',{}).get('code')=='PAYMENT_TERMINAL_STATE_CONFLICT', (r.status_code,r.text)
    # A nonterminal intent still processes a valid success.
    r=send(client,{'id':'evt_v388_success_'+suffix,'type':'payment_succeeded','payment_intent_id':'pi_v388_pending_'+suffix,'amount_czk':120,'currency':'CZK'})
    assert r.status_code==200, (r.status_code,r.text)
    with main.conn() as c:
        statuses={state:c.execute('SELECT status FROM payment_intents WHERE id=?',('pi_v388_'+state+'_'+suffix,)).fetchone()['status'] for state,_ in cases}
    assert statuses=={'succeeded':'succeeded','failed':'failed','cancelled':'cancelled','pending':'succeeded'}, statuses
    print('V388_V059_TERMINAL_PAYMENT_IMMUTABILITY_PASS late_failure_ignored=succeeded_same_terminal_ignored=failed_conflicts=409 valid_success=processed')
