"""v1.391 regression: signed payment webhooks must have a JSON object root."""
import os, sys, json, hmac, hashlib, tempfile, uuid
from pathlib import Path
from fastapi.testclient import TestClient
ROOT=Path(__file__).resolve().parent
os.environ['WUNOO_PAYMENT_WEBHOOK_SECRET']='test-secret-v391'
os.environ['WUNOO_DB_PATH']=os.path.join(tempfile.gettempdir(),'wunoo_v391_'+uuid.uuid4().hex+'.db')
sys.path.insert(0,str(ROOT))
from app import main
suffix=uuid.uuid4().hex[:10]
CASES=[b'null',b'[]',b'"text"',b'123',b'true']
PATHS=['/api/v059/payment/webhook','/api/v140/payment/webhook','/api/v141/payment/webhook']
def signed_post(client,path,raw):
    sig='sha256='+hmac.new(b'test-secret-v391',raw,hashlib.sha256).hexdigest()
    return client.post(path,content=raw,headers={'X-WUNOO-Signature':sig,'Content-Type':'application/json'})
with TestClient(main.app) as client:
    for path in PATHS:
        for raw in CASES:
            r=signed_post(client,path,raw)
            assert r.status_code==400,(path,raw,r.status_code,r.text)
            detail=r.json().get('detail')
            assert isinstance(detail,dict) and detail.get('code')=='WEBHOOK_BODY_INVALID',(path,raw,r.text)
    with main.conn() as c:
        n=c.execute("SELECT COUNT(*) n FROM payment_webhook_events WHERE provider_event_id LIKE ?",('%'+suffix+'%',)).fetchone()['n']
    assert n==0,n
print('V391_WEBHOOK_JSON_ROOT_OBJECT_GUARD_PASS paths=3 invalid_roots=5 each total=15 no_500=true')
