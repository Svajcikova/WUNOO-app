# WUNOO v1.384 Candidate — v1.059 concurrent payment webhook deduplication

## Change
- The legacy `/api/v059/payment/webhook` processor now claims a provider event within a write transaction before processing the payment intent.
- SQLite acquires `BEGIN IMMEDIATE` before claiming the event; `INSERT ... ON CONFLICT(provider_event_id) DO NOTHING` makes duplicate claims explicit and returns the existing event status instead of leaking a uniqueness exception.
- This addresses concurrent duplicate delivery on the SQLite-backed legacy v1.059 path. The route still uses the legacy SQLite connection and is not evidence of PostgreSQL integration readiness.

## Verification
- `TEST_V384.py` — concurrent same-event delivery: exactly one webhook event row, one successful processing, one duplicate response, payment intent finalized once.
- Previous v1.383 regression and financial/security test suites should be run before release.
- PostgreSQL integration test remains outstanding.

## Status
Candidate only; not production-approved and not pushed to GitHub.
