"""v1.382 regression: payout idempotency cache is read after PostgreSQL order lock."""
import os, sys, tempfile, uuid
from pathlib import Path
from fastapi import HTTPException

ROOT = Path(__file__).resolve().parent
source = (ROOT / "app" / "main.py").read_text(encoding="utf-8")
route = source.split('@app.post("/api/v120/finance/orders/{order_id}/payout")', 1)[1].split('@app.get("/api/v120/finance/exceptions")', 1)[0]
lock_pos = route.find('SELECT id FROM orders WHERE id=? FOR UPDATE')
cache_pos = route.find('_v118_cached_command(c,scope,idempotency_key,payload)')
assert lock_pos >= 0 and cache_pos >= 0 and lock_pos < cache_pos, "PostgreSQL order lock must precede idempotency cache read"

DB = os.path.join(tempfile.gettempdir(), "wunoo_v382_" + uuid.uuid4().hex + ".db")
os.environ["WUNOO_DB_PATH"] = DB
sys.path.insert(0, str(ROOT))
from app import main
main.init_db()
with main.core_db_connect() as c:
    main.migrate_v120(c); main.migrate_v118(c); main.migrate_v122(c); c.commit()
ts = main.now(); uid = "u382_" + uuid.uuid4().hex[:8]; cid = "c382_" + uuid.uuid4().hex[:8]; mid = "m382_" + uuid.uuid4().hex[:8]; oid = "o382_" + uuid.uuid4().hex[:8]
with main.core_db_connect() as c:
    c.execute("INSERT INTO users(id,email,name,role,active,created_at,password_hash) VALUES(?,?,?,?,?,?,?)", (uid,uid+"@test.invalid","V382 Admin","admin",1,ts,"x"))
    c.execute("INSERT INTO customers(id,name,email,created_at) VALUES(?,?,?,?)",(cid,"V382 Customer",uid+"@test.invalid",ts))
    c.execute("INSERT INTO merchants(id,name,created_at) VALUES(?,?,?)",(mid,"V382 Merchant",ts))
    c.execute("INSERT INTO orders(id,customer_id,merchant_id,status,subtotal_czk,service_fee_czk,delivery_fee_czk,total_czk,address,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(oid,cid,mid,"delivered",100,0,0,100,"V382 test",ts,ts))
    c.commit()
original_user = main.current_user
original_snapshot = main._v120_finance_snapshot
main.current_user = lambda _auth: {"id":uid,"role":"admin"}
def fake_snapshot(c, order_id):
    order = c.execute("SELECT * FROM orders WHERE id=?", (order_id,)).fetchone()
    return {"order":order,"status":"reconciled","gross_czk":100.0,"refunded_czk":0.0,"merchant_czk":80.0,"courier_czk":10.0,"platform_czk":10.0,"settlement_id":"settle_382"}
main._v120_finance_snapshot = fake_snapshot
try:
    first = main.v120_payout(oid, None, "v382-same-key")
    replay = main.v120_payout(oid, None, "v382-same-key")
    assert first["status"] == replay["status"] == "completed", (first,replay)
    assert first["payouts"] == replay["payouts"], (first,replay)
    with main.core_db_connect() as c:
        count = c.execute("SELECT COUNT(*) n FROM v120_payouts WHERE order_id=?",(oid,)).fetchone()["n"]
        commands = c.execute("SELECT COUNT(*) n FROM v118_command_log WHERE scope=? AND idem_key=?",(f"v120:payout:{uid}:{oid}","v382-same-key")).fetchone()["n"]
    assert count == 3, count
    assert commands == 1, commands
    print("V382_PAYOUT_IDEMPOTENCY_LOCK_ORDER_PASS payouts=3 command_records=1 replay_identical=True")
finally:
    main.current_user = original_user
    main._v120_finance_snapshot = original_snapshot
    with main.core_db_connect() as c:
        c.execute("DELETE FROM finance_ledger_entries WHERE order_id=?",(oid,))
        c.execute("DELETE FROM v120_payouts WHERE order_id=?",(oid,))
        c.execute("DELETE FROM v118_command_log WHERE scope=?",(f"v120:payout:{uid}:{oid}",))
        c.execute("DELETE FROM orders WHERE id=?",(oid,)); c.execute("DELETE FROM customers WHERE id=?",(cid,)); c.execute("DELETE FROM merchants WHERE id=?",(mid,)); c.execute("DELETE FROM users WHERE id=?",(uid,)); c.commit()
    try: os.remove(DB)
    except OSError: pass
