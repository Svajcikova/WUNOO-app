"""v1.400 regression: low/invalid gross must not create unbalanced v1.062 settlement."""
import os, sys, tempfile, uuid, math
from pathlib import Path
from fastapi import HTTPException
ROOT = Path(__file__).resolve().parent
os.environ['WUNOO_DB_PATH'] = os.path.join(tempfile.gettempdir(), 'wunoo_v400_' + uuid.uuid4().hex + '.db')
sys.path.insert(0, str(ROOT))
from app import main

# Exact lower bound is valid and must balance to the cent.
minimum = main._v400_compute_v062_settlement(47.56)
assert minimum['merchant_payout_czk'] == 0.0
assert round(minimum['platform_fee_czk'] + minimum['merchant_payout_czk'] + minimum['courier_payout_czk'], 2) == minimum['gross_czk']
assert minimum['variance_czk'] == 0.0

for bad in (47.55, 39, 0, -1, float('nan'), float('inf'), True, 'not-money', None):
    try:
        main._v400_compute_v062_settlement(bad)
    except HTTPException as exc:
        assert exc.status_code == 409, (bad, exc.status_code)
        assert exc.detail['code'] in {'SETTLEMENT_AMOUNT_INVALID', 'SETTLEMENT_AMOUNT_BELOW_MINIMUM'}
    else:
        raise AssertionError(f'accepted invalid/too-small gross: {bad!r}')

for gross in (50, 99.99, 100, 250, 1000):
    row = main._v400_compute_v062_settlement(gross)
    assert min(row[k] for k in ('gross_czk','platform_fee_czk','merchant_payout_czk','courier_payout_czk')) >= 0
    assert abs(row['gross_czk'] - row['platform_fee_czk'] - row['merchant_payout_czk'] - row['courier_payout_czk']) <= 0.01
print('V400_SETTLEMENT_MINIMUM_AND_BALANCE_PASS lower_bound=47.56 invalid_cases=9 valid_amounts=5')
