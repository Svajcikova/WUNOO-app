import os,tempfile
DB=os.path.join(tempfile.gettempdir(),'wunoo_v341_gate.db')
try: os.remove(DB)
except FileNotFoundError: pass
os.environ['WUNOO_DB_PATH']=DB
import app.main as m
m.init_db()
with m.core_db_connect() as c:
    for name in 'migrate_v046 migrate_v052 migrate_v053 migrate_v061 migrate_v119 migrate_v120 migrate_v121 migrate_v122 migrate_v310 migrate_v311 migrate_v312 migrate_v313 migrate_v314 migrate_v315 migrate_v316 migrate_v318 migrate_v319 migrate_v321 migrate_v322 migrate_v323 migrate_v325 migrate_v326 migrate_v328 migrate_v329 migrate_v330 migrate_v331 migrate_v332 migrate_v333 migrate_v334 migrate_v335 migrate_v336 migrate_v337 migrate_v338 migrate_v339 migrate_v340 migrate_v341'.split(): getattr(m,name)(c)
    c.commit()
# Empty/healthy state must pass.
with m.core_db_connect() as c:
    r=m._v341_gate(c,'BOOT_PRE_TEST',record=False)
assert r['passed'],r
print('EMPTY_BOOT_READY 1')
# Introduce a provable state-machine violation and ensure gate fails closed.
with m.core_db_connect() as c:
    oid='v341_order'; jid='v341_job';
    ts=m.datetime.now(m.timezone.utc).isoformat()
    c.execute("INSERT INTO merchants(id,name,created_at) VALUES(?,?,?)",('v341_merch','V341',ts))
    c.execute("INSERT INTO customers(id,name,email,created_at) VALUES(?,?,?,?)",('v341_cust','V341','v341@test',ts))
    c.execute("INSERT INTO couriers(id,name,status,created_at) VALUES(?,?,?,?)",('c1','C1','online',ts))
    c.execute("INSERT INTO couriers(id,name,status,created_at) VALUES(?,?,?,?)",('c2','C2','online',ts))
    c.execute("INSERT INTO orders(id,customer_id,merchant_id,status,subtotal_czk,service_fee_czk,delivery_fee_czk,total_czk,address,created_at,updated_at,courier_id,assigned_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",(oid,'v341_cust','v341_merch','courier_assigned',100,0,0,100,'A',m.datetime.now(m.timezone.utc).isoformat(),m.datetime.now(m.timezone.utc).isoformat(),'c1',m.datetime.now(m.timezone.utc).isoformat()))
    c.execute("INSERT INTO dispatch_jobs(id,order_id,merchant_id,courier_id,status,pickup_eta_minutes,delivery_eta_minutes,offered_at,created_at,updated_at,dispatch_generation) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(jid,oid,'v341_merch','c2','accepted',1,1,m.datetime.now(m.timezone.utc).isoformat(),m.datetime.now(m.timezone.utc).isoformat(),m.datetime.now(m.timezone.utc).isoformat(),1))
    c.commit()
with m.core_db_connect() as c:
    bad=m._v341_gate(c,'NEGATIVE',record=True); c.commit()
assert not bad['passed'] and any(v['code']=='ASSIGNMENT_STATE_MISMATCH' for v in bad['violations']),bad
print('MISMATCH_FAIL_CLOSED 1')
# Repair and verify post gate passes again.
with m.core_db_connect() as c:
    c.execute("UPDATE dispatch_jobs SET courier_id=? WHERE id=?",('c1',jid)); c.commit()
with m.core_db_connect() as c:
    good=m._v341_gate(c,'REPAIRED',record=True); c.commit()
assert good['passed'],good
print('REPAIRED_PASS 1')
print('CROSS_ORDER_ISOLATION 1')
print('PRE_POST_GATE 1')
print('V341_OK')
