import math
from app.main import _finite_money

for raw in (float('nan'), float('inf'), float('-inf')):
    try:
        _finite_money(raw)
        raise AssertionError(f'non-finite accepted: {raw!r}')
    except Exception as e:
        assert getattr(e, 'status_code', None) == 400, (raw, e)

s=open('app/main.py',encoding='utf-8').read()
for needle in [
    'amount=round(_finite_money(body.get("amount_czk",0)),2)',
    'amount=_finite_money(body.get("amount_czk",0))',
    'payload["amount_czk"]=round(_finite_money(body.get("amount_czk",0)),2)',
    'amount=round(_finite_money(body.get("amount_czk",0) or 0),2)',
    'approve=round(_finite_money(body.get("refund_approved_czk",0) or 0,"refund_approved_czk"),2)',
    'lat=_finite_money(body.get("latitude"),"latitude");lon=_finite_money(body.get("longitude"),"longitude")',
]:
    assert needle in s, needle
assert 'if not (-90 <= lat <= 90 and -180 <= lon <= 180)' in s
print('V374_NONFINITE_MONEY_LOCATION_GUARD_PASS')
