# WUNOO v1.386 Candidate — v1.140 payment webhook hardening

## Changes
- Hardened `POST /api/v140/payment/webhook` to serialize state changes for the same payment intent. SQLite uses `BEGIN IMMEDIATE`; PostgreSQL starts a transaction and locks the payment-intent row with `FOR UPDATE`.
- Added immutable event-ID/payload binding. Exact replays are idempotent; reusing a provider event ID with a different payload, event type, or payment-intent ID returns HTTP 409.
- Added conflict-safe event insertion (`ON CONFLICT DO NOTHING`) so a concurrent duplicate delivery can return the persisted result instead of failing on a unique constraint.
- Explicitly preserve terminal payment state: late failure/cancellation after success is ignored; a contradictory event against a failed/cancelled intent is recorded as conflict and rejected.
- Added `TEST_V386.py` for concurrent duplicate delivery, exact replay, changed payload, and late failure after success.

## Verification
- `python -m compileall -q app` — PASS.
- `TEST_V386.py` — PASS on SQLite: two concurrent same-event deliveries, one duplicate response, changed payload HTTP 409, late failure ignored, intent remains succeeded.
- `TEST_V385.py`, `TEST_V384.py`, `TEST_V383.py`, `TEST_V382.py`, `TEST_V381.py`, `TEST_V380.py`, `TEST_V379.py`, `TEST_V378.py`, `TEST_V377.py`, `TEST_V372.py`, `TEST_V362.py` — PASS when run individually.
- ZIP integrity check — PASS.

## Limitations / status
- PostgreSQL logic is implemented using the backend adapter's transaction and row-lock path, but no live PostgreSQL integration test was run in this environment.
- Candidate only; not production-approved and not pushed to GitHub.
