"""v1.396 regression: refund-ledger replay only accepts a complete balanced pair."""
import os, sys, tempfile, uuid
from pathlib import Path
from fastapi import HTTPException
ROOT = Path(__file__).resolve().parent
os.environ['WUNOO_DB_PATH'] = os.path.join(tempfile.gettempdir(), 'wunoo_v396_' + uuid.uuid4().hex + '.db')
sys.path.insert(0, str(ROOT))
from app import main
main.init_db()

order_id = 'ord-v396'
refund_id = 'ref-v396'
provider_ref = 'provider-ref-v396'
with main.conn() as c:
    main._v234_record_refund_ledger(c, order_id, 125.50, provider_ref, refund_id)
    c.commit()
    # Exact replay is idempotent and does not duplicate either ledger leg.
    main._v234_record_refund_ledger(c, order_id, 125.50, provider_ref, refund_id)
    rows = c.execute("SELECT account,direction,amount_czk FROM finance_ledger_entries WHERE entry_type='refund_v234' AND reference=?", (provider_ref,)).fetchall()
    assert len(rows) == 2, len(rows)
    assert {(r['account'], r['direction'], round(float(r['amount_czk']), 2)) for r in rows} == {
        ('customer_refunds', 'debit', 125.50), ('payment_clearing', 'credit', 125.50)
    }
    # Simulate legacy/corrupt partial persistence: replay must fail closed.
    c.execute("DELETE FROM finance_ledger_entries WHERE entry_type='refund_v234' AND reference=? AND direction='credit'", (provider_ref,))
    c.commit()
    try:
        main._v234_record_refund_ledger(c, order_id, 125.50, provider_ref, refund_id)
    except HTTPException as exc:
        assert exc.status_code == 409, (exc.status_code, exc.detail)
        assert exc.detail['code'] == 'REFUND_LEDGER_INCONSISTENT', exc.detail
    else:
        raise AssertionError('partial refund ledger pair was silently accepted')
print('V396_REFUND_LEDGER_REPLAY_INTEGRITY_PASS exact_replay=PASS partial_pair=409')
